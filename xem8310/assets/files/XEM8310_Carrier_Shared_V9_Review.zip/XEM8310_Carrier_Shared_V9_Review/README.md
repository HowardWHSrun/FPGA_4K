# XEM8310 carrier V9 — shared power and JTAG schematic

Open `XEM8310_Carrier_Shared_V9.kicad_pro` in KiCad 10. This is a one-page schematic revision. No V9 PCB is included; V8 remains the separately preserved six-layer rough placement reference.

V9 retains eight GT recording links, regular-I/O stimulation and PCIe x4. One U800 TPS56637 3.3 V source feeds eight separately protected eFuse/reset/fault branches. The eight headstage JTAG translators/supervisors become one shared translator/supervisor plus eight TS3A27518E signal switches. XEM keeps a separate JTAG path. Total: 351 physical components, 71 fewer than V8.

Native ERC: zero errors and 1,193 warnings (1,111 off-grid endpoints, 82 same local/global labels). Independent pin/metadata checks preserve the retained circuits after the approved shared power joins. Manufacturer references and the Codex adaptation are identified directly on the schematic, with Function and Source / changes items in adjacent boxes.

Normal 3.3 V allocation: 8 x 0.55 A + 0.05 A = 4.45 A. All eight upper eFuse current-limit screens total about 6.19 A, above the 6 A converter rating; simultaneous limit operation is not promised. Shared-bus fault interaction, cable/load/startup/thermal behavior and powered operation remain unqualified. The shared target-presence circuit is not a remote rail-good monitor.

Programming target change: stop TCK; SW700 EXTERNAL; rotate SW600; SW700 ONBOARD; wait at least 50 ms. Positions 1 = XEM, 2..9 = headstages 1..8, 10..12 = off. Hot-running switching and rail-collapse response are unqualified. HDMI pin 1 senses target voltage; it does not power the local translator.

This public review project includes project-local 2D libraries and intentionally omits all model payloads. Unchanged model references can report missing files locally. There is no paired V9 PCB or assembly view.

Three inherited generic support parts, C700/R700/R701, still have unspecified manufacturer MPN/datasheet fields; no part choice was invented. This is a review checkpoint. V9 PCB update, routing, PCIe/DMA/host firmware, remote stimulation-GPIO adaptation and hardware qualification remain pending.
