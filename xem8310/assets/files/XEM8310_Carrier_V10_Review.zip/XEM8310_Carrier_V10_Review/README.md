# XEM8310 carrier V10 public review source

Open `XEM8310_Carrier_Placement_V10.kicad_pro` in KiCad 10. This package contains the exact saved schematic, PCB and current project files, their project-local 2D libraries/tables, and library notices. The project file includes KiCad's saved V10 reference normalization; schematic and PCB bytes are unchanged.

V10 pairs the simplified V9 circuit with a rough PCB placement: eight custom micro-HDMI ports, PCIe x4, one shared 3.3 V headstage converter with eight protected branches, and shared selected headstage JTAG with a separate XEM branch. There are 351 electrical components, 366 physical footprints and six copper layers.

No new routing or zone refill was performed. Native connectivity reports 776 unrouted edges. The saved check reports zero schematic-parity findings, zero ERC errors with 1193 warnings, and 2126 DRC violations. Inherited ignored checks remain disclosed in `review-status.json`. Existing 5,735 routing objects, 12 copper graphic polygons and 11 zones/cached fills are unchanged from V8.

All 57 newly generated JTAG components passed the bounded saved-geometry contact screens. The 365 retained pre-existing contact records comprise 282 isolated legacy-route, 69 cached-fill and 14 copper-graphic interactions; cleanup/routing remain open. This is not a fabrication release.

## Body model policy

All model payloads are intentionally omitted, including supplier STEP and local native 3D meshes. The unchanged CAD retains model references, so local 3D viewing can report missing model files. The website's nominal bodies are public review aids, not an exact assembly model. The complete local model archive and private audits/history/preferences are excluded.
