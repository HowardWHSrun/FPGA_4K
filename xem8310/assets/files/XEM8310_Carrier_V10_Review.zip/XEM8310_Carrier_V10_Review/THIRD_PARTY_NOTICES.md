# Third-party provenance

The included KiCad-derived 2D library material retains the KiCad library license and electronic-design exception in `libraries/Shared_JTAG_V9/KiCad_Libraries_LICENSE.md`. Custom parts and manufacturer-derived land patterns identify their references in the native source. The carrier includes design material derived from Opal Kelly BRK8310-A01. This notice does not relicense third-party material; provenance and applicable upstream notices remain with their respective files. No supplier 3D geometry is included.
