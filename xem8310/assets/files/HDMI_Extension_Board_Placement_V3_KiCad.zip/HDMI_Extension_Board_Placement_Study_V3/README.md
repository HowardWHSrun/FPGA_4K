# HDMI Extension Board — V3 placement study

Open `HDMI_Extension_Board_Placement_Study_V3.kicad_pro` in KiCad 10.0.6 or newer. Keep this folder and both local library tables together.

This is the saved six-layer V3 placement study with its original paired schematic and rules. It has no routed tracks or power/ground pours. Its paired schematic predates TP710–TP713; use the separate V5 schematic as the current circuit source. Do not mistake the two snapshots for a synchronized release.

PCB and library model references are removed in this public package; no supplier 3D payloads or broken model links are included. All non-3D PCB content, schematic content, positions, pins and nets are preserved. The website supplies a separate rotatable 3D placement preview with nominal component envelopes, not verified mechanical models.

Original BRK8310, historical library identifiers and source revision text are retained for provenance. Product name: HDMI Extension Board. KiCad standard library material is CC-BY-SA 4.0 with the KiCad design exception: https://www.kicad.org/libraries/license/ . Original project/manufacturer attribution is retained; this package grants no new rights over third-party sources.

Review snapshot, not a manufacturing release. Routing, physical fit, impedance, power/cable, assembly and functional qualification remain open. No Gerbers are supplied for this unrouted study.
