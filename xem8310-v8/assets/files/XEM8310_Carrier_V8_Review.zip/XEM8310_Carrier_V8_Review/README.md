# XEM8310 Carrier V8 — public review source

This archive contains the exact frozen V8 KiCad schematic, PCB and project files, project-local symbol/footprint libraries, and library tables. Open `XEM8310_Carrier_Placement_V8.kicad_pro` in KiCad 10.

## Review status

This is a rough placement checkpoint. Eight custom micro-HDMI ports provide GT recording inputs, ordinary-I/O stimulation commands, protected power, and selected JTAG. The PC link is PCIe ×4.

- Six copper layers; 437 footprints (422 electrical and 15 mechanical references).
- No new routing or zone refill was performed. The saved native check has 879 open connections.
- Exactly 24 source signal-isolation segments were removed. The remaining 5,735 source copper objects and all 11 existing zones/fills were preserved.
- The placement check found no new-pad contacts on the 2,712 active source copper objects and no native net-name mismatches across retained copper.
- 483 contacts with isolated legacy NC/header/refclk/orphan route remnants remain explicitly deferred to obsolete-copper cleanup and routing. Historical filled-zone interactions are also deferred.

## Model policy

This public archive intentionally omits all body-model payloads, including supplier STEP and native full models. Model references remain in the unchanged CAD files, so opening 3D locally may report missing models. The public web 3D view uses native PCB geometry with nominal component bodies; it is not an exact body-model assembly.

The complete local V8 archive remains unchanged and is not published here. Routing, manufacturing and powered-operation qualification remain incomplete. This review archive is not a fabrication release.
