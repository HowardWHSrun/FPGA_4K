# R2 assembly visual study

Open `XEM8305_LDO_Carrier_Connector_Foundation.kicad_pro`, then open KiCad 3D Viewer. This copy adds mechanical model references for the official XEM8305 model, the actual saved LDO PCB and supplier-drawing nominal J1/J19 envelopes. Original source pad nets, copper routing and connector positions are retained. Added VIS_* footprints have no pads and are excluded from BOM and position files.

The primary PCB shows the nominal assembled placement. `Assembly_Exploded_Visual_Only.kicad_pcb` separates the module and LDO by an additional 35 mm for visibility. Both are visualization studies, not build or fabrication designs. Do not use exploded spacing for mechanics.

J1 and J19 centers align in XY after flipping the saved LDO. LDO mating gap is nominal 2 mm; module separation is nominal 5 mm. These do not verify physical seating, clearance, installed population or tolerance stack. Hirose STEP retrieval returned 403, so the four outer boxes are explicitly nominal envelopes: they omit cavities and contacts and overlap during mating. The source LDO J19 footprint has 24 signal-pad positions plus four source end pads; the end-pad function/numbering requires confirmation.

All additional 3D references use `${KIPRJMOD}/models/`; embedded Samtec source models and restored local project libraries are preserved. See `Study_Manifest.json` for hashes, source paths and geometry qualification.
