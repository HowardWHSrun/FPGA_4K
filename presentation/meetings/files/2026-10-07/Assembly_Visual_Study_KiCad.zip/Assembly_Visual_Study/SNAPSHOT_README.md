# Assembly visualization study

The original electrical source remains separate in Board_Howard_KiCad.zip. This study preserves its copper, nets and connector positions and adds mechanical model references. Keep all local libraries/models beside the project. See START_HERE.md for nominal seating and visualization-only limits.
