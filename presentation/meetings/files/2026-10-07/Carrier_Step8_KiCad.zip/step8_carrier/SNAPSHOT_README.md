# Applied Step 8 baseline

Meeting review, 7 October 2026.

Four copper layers, 242 track segments, 105 vias and one dedicated In1.Cu DGND plane. Physical DRC and assigned opens are zero. The 204 parity warnings remain recorded, with 234 unassigned contacts checked independently. This five-connector foundation still needs power/startup circuitry, firmware, timing and physical qualification.

Open the native `XEM8305_LDO_Carrier_Connector_Foundation.kicad_pro` project and keep every included library beside it. M1 uses the `hardware/` subfolder. Standard KiCad 10 models remain an installed-library dependency. Nominal model envelopes and omitted Hirose housings do not establish populated assembly fit.

Native PCB, schematic and project bytes are preserved. The received carrier’s omitted local symbol/footprint libraries were supplied from the verified connector foundation. The original LDO footprint table uses a relative path to its included custom footprint. These library-lookup repairs preserve the circuit and layout. The M1 source README’s 40 × 40 mm value is stale; the native outline measures 41 × 41 mm.

This public package excludes hidden histories, caches, local personal settings, private correspondence/audio and manufacturing outputs.
