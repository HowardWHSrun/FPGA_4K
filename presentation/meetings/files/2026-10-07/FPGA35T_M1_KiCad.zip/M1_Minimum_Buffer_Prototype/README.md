# M1 custom 35T prototype

Meeting review, 7 October 2026.

Measured 41 × 41 mm. 287 components and 1,091 expected unrouted PCB connections. No tracks, vias or copper planes. Native ERC, physical DRC and schematic parity are zero under delivered settings. Power, timing, direct-interface behavior, routing and fabrication qualification remain open.

Open the native `FPGA35T_M1.kicad_pro` project and keep every included library beside it. M1 uses the `hardware/` subfolder. Standard KiCad 10 models remain an installed-library dependency. Nominal model envelopes and omitted Hirose housings do not establish populated assembly fit.

Native PCB, schematic and project bytes are preserved. The received carrier’s omitted local symbol/footprint libraries were supplied from the verified connector foundation. The original LDO footprint table uses a relative path to its included custom footprint. These library-lookup repairs preserve the circuit and layout. The M1 source README’s 40 × 40 mm value is stale; the native outline measures 41 × 41 mm.

This public package excludes hidden histories, caches, local personal settings, private correspondence/audio and manufacturing outputs.
