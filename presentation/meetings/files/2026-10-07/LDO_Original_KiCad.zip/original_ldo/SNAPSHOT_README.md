# Original ASIC LDO reference

Meeting review, 7 October 2026.

Nine regulator/reference stages, with 23 direct digital signal paths. Actual fitted population, rail windows/current, signed high-stage reference, ground bond, power order and mating remain unverified. This meeting copy does not establish clean source ERC/DRC qualification.

Open the native `PCB.kicad_pro` project and keep every included library beside it. M1 uses the `hardware/` subfolder. Standard KiCad 10 models remain an installed-library dependency. Nominal model envelopes and omitted Hirose housings do not establish populated assembly fit.

Native PCB, schematic and project bytes are preserved. The received carrier’s omitted local symbol/footprint libraries were supplied from the verified connector foundation. The original LDO footprint table uses a relative path to its included custom footprint. These library-lookup repairs preserve the circuit and layout. The M1 source README’s 40 × 40 mm value is stale; the native outline measures 41 × 41 mm.

This public package excludes hidden histories, caches, local personal settings, private correspondence/audio and manufacturing outputs.
