# HDMI Extension Board enclosure V3 · edited 10 Nov 2026, 13:53 CST

**Request (Howard, 10 Nov 2026, relayed):** "can u make the enclosure include the adapter and all we need to connect from our computer is the usbc?"

V3 is [V2](../08_HDMI_Extension_Board_Enclosure_V2/START_HERE.md) with a Thunderbolt-to-PCIe adapter built in. The board's PCIe card edge seats directly in the adapter, which stands in a keel under the back of the box, so the only computer cable is one USB-C (Thunderbolt). The keel tilts the box 22° like a console. V2 is unchanged.

**Status: CAD concept only. Thermal performance, physical fit and the Thunderbolt/PCIe link are not verified. Nothing has been bought, printed or machined.** No board CAD was changed.

- **3D page:** [viewer/index.html](viewer/index.html). It needs a local server: `cd ~/kicad_work/enclosure_V3/deliver && python3 -m http.server 8817`, then http://localhost:8817/viewer/index.html. New views: Computer port, Side.
- **Fit check:** [review/fitcheck.json](review/fitcheck.json) · **dimensions used:** [review/enclosure_meta.json](review/enclosure_meta.json)
- **GLBs for the deck overview:** [deck_glb/](deck_glb/), in the board frame (X = board x, Y = height above the board bottom, Z = board y, mm), not tilted. Tilt for display: 22.06° about X.
- **Rebuild:** [scripts/enclosure3.py](scripts/enclosure3.py), `fitcheck3.py`, `deliver3.sh`. Working copy `~/kicad_work/enclosure_V3` (uses the V2 venv).

## Adapter: DFR1169, not DFR1168

| | DFR1168 (suggested) | **DFR1169 (used)** |
|---|---|---|
| Vendor size | 220 × 65 mm | **100 × 62 × 17 mm**, 90 g |
| Power input | ATX 24-pin only | **12 V on a DC 5.5 × 2.1 jack** (also 12 V PD, CPU 4+4, large 4-pin) |
| Chip and link | ASM2464PD, USB4, PCIe 4.0 x4 | Intel JHL6340, Thunderbolt 3, PCIe 3.0 x4 |
| Fit | 36 mm longer than the whole V2 box, and needs a DC-to-ATX supply inside | fits a keel under the box |

- DFR1168 does not work here: too long, and ATX-only power. Sources: [DFR1168 wiki](https://wiki.dfrobot.com/DFR1168), [DFR1169 wiki](https://wiki.dfrobot.com/DFR1169) and its [dimension drawing](https://dfimg.dfrobot.com/wiki/18624/DFR1169_thunderbolt-to-pcie-module_dimension_V1.0.pdf).
- DFR1169's vendor table lists Windows 10/11, Linux and "Mac Os", and "USB4, Thunderbolt 3, Thunderbolt 4" hosts. It is Thunderbolt 3 silicon at PCIe Gen 3 x4 (32 Gb/s). The board's link is x4, so the width matches.
- **Taken from the vendor drawing:** outline 100 × 62, hole pattern (46 mm apart, rows 54 mm apart, 3 mm from the slot-side edge, plus a 4th hole 20 mm below), slot row 10 mm from the long edge, latch 18.5 mm past the board, Thunderbolt port on the short edge about 34–44 mm from the slot-side edge.
- **Approximate in the model:** the DC jack, 4-pin, CPU 4+4 and PD positions (read from the picture), part heights, and how far the Type-C sticks out.

## How it goes together

- **Direct seating, no riser.** The card edge (fingers x 109.68–160.98, tips at y 162.054) plugs into the x16 slot. Reason: no extra connector pair or ribbon in the PCIe lanes, no second unverified part, and the adapter's 100 mm length lines up under the board.
- **Why a keel:** the slot is 10 mm from the adapter's long edge, and the key end fixes which way round it goes, so the adapter hangs 51.2 mm below the board's mid-plane and only 10 mm above. The keel is 136.5 × 34.8 mm in plan and 48 mm deep.
- **Assembly:** fit four M3 × 6 pillars to the adapter back. Plug the board into the adapter on the bench, then lower both into the base together (the keel is open to the main cavity). Four M3 screws go in from outside the back wall. The rest is as V2.
- **Seating depth** is nominal (7.6 mm); slot mouth at y 154.45, 0.5 mm past the tongue capacitors C13–C20.

## Outside

| Opening | Where |
|---|---|
| **Computer: one USB-C (Thunderbolt)** | east end of the keel, engraved PC; 4.2 × 9.8 mm port in a 1.2 mm wall with an 8.4 × 14.4 mm plug pocket. The receptacle stands on edge. |
| Eight HDMI ports | as V2 |
| 12 V power | J4, as V2 |
| Service (not needed day to day) | JTAG USB-C, XEM USB 3, selector dial, SW601 slider, header and J920 windows, as V2. The V2 PCIe riser port is gone. |

**Size:** 184.1 × 139.7 mm in plan; 34.4 mm thick with the keel reaching 48 mm lower. On its feet it is tilted 22°, about 33 mm high at the front and 85 mm at the back.

## Power

- **USB-C alone cannot power it.** A Thunderbolt host port supplies about 15 W. Running from USB-C would need a USB-PD input designed in (a 60–100 W PD source and a sink controller); that is not in V3.
- **One 12 V input: J4.** The adapter is fed inside from the board's 12 V: a lead from TP710 (+VDCIN, at 117.0, 58.0) and TP709 (DGND, at 133.5, 57.0) to a 5.5 × 2.1 plug in the adapter's DC jack, routed down the west end of the keel (27 mm of room for the plug).
  - The slot's own 12 V pins are not an option: on V35 they go only to test point TP20.
  - Soldering two wires to test points is a hand modification of an assembled board. A Y-cable outside would avoid it but is a second cable.
- **Budget at 12 V:**

| | Expected | High |
|---|---:|---:|
| Board + XEM8310 + 8 ports ([3 Nov estimate](../../2026-11-03_FPGA_Work/20_HDMI_Extension_Board_Power_Estimate_And_Plan_V1/START_HERE.md)) | 22–28 W | 44 W |
| Adapter (my estimate; vendor gives none) | 3–5 W | 5 W |
| **Total at J4** | **about 25–33 W (2.1–2.8 A)** | **about 49 W (4.1 A)** |

## Open points

- **Thermal:** nothing simulated or measured. The adapter sits in a closed keel with 11 floor slots; the U700 heat sinks are as V2; there is still no fan.
- **Adapter size:** from the vendor drawing only. Measure a real DFR1169 (slot position, Type-C protrusion, tallest part, hole pattern) before making the base.
- **Link:** Thunderbolt 3 chip, PCIe Gen 3 x4. Whether the XEM8310 PCIe endpoint enumerates through it on the lab's Mac is untested.
- **macOS driver:** the FPGA's PCIe endpoint needs a macOS driver (for example a DriverKit PCI driver); none exists in this workspace.
- **Power:** J4 and adapter-jack current ratings against 4.1 A, and the TP710/TP709 tap, need checking on the real parts.
- **Board revision:** measured from V35. V37 (10 Nov) has the same outline and part positions and adds holes MH2 (223.33, 131.15) and MH3 (147.83, 69.15); they clear every post and pin and could take screws in a later revision.
- **Tilt and cables:** 22° is steep; the USB-C plug sits under the overhang at the back. HDMI cable pull on a tilted box is untested.
- Everything listed as unverified in V2 still applies.

[10 November index](../START_HERE.md)
