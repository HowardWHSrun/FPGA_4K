# HDMI Extension Board enclosure V2 · edited 10 Nov 2026, 13:03 CST

**Request (Howard, 10 Nov 2026):** "can we make a nice looking enclosure for the xem and BRK? I want it to have at the top and bottom near the power source some heat sink, but the other part to be 就是透明但是里面是银色的感觉, a bit like the design of the Logitech Alto Keys K98M."

V2 is a clear, thick-walled shell with a silver layer showing through it, and finned aluminium heat sinks through the top and bottom faces at the board's 12 V input. It holds the HDMI Extension Board V35 with the XEM8310 fitted. [V1](../../2026-11-04_FPGA_Work/10_HDMI_Extension_Board_Enclosure_V1/START_HERE.md) (MCU-style printed box with a fan) is unchanged.

**Status: CAD concept only. Thermal performance and physical fit are not verified. Nothing has been printed or machined.** No board CAD was changed.

- **3D page:** [viewer/index.html](viewer/index.html). It needs a local server: `cd ~/kicad_work/enclosure_V2/deliver && python3 -m http.server 8816`, then http://localhost:8816/viewer/index.html. Views: closed, exploded, lid off, underside, HDMI side, power corner; the silver deck and clear shell can be switched off.
- **Fit check:** [review/fitcheck.json](review/fitcheck.json) · **dimensions used:** [review/enclosure_meta.json](review/enclosure_meta.json)
- **Rebuild:** [scripts/enclosure2.py](scripts/enclosure2.py) (CadQuery, all dimensions at the top), `fitcheck2.py`, `deliver.sh`. Working copy: `~/kicad_work/enclosure_V2`.

## Parts

| Part | Files | Suggested material | Size |
|---|---|---|---|
| Clear lid | [STEP](models/Clear_Lid_V2.step) · [STL](models/Clear_Lid_V2.stl) | clear SLA resin (polished), machined acrylic or polycarbonate; clear PETG for a draft | 184.1 × 128.75 × 24.7 mm, 140 cm³ |
| Clear base | [STEP](models/Clear_Base_V2.step) · [STL](models/Clear_Base_V2.stl) | same as the lid | 184.1 × 128.75 × 9.7 mm (pin to 12), 88 cm³ |
| Silver top deck | [STEP](models/Silver_Top_Deck_V2.step) · [STL](models/Silver_Top_Deck_V2.stl) | 1.5 mm aluminium sheet, bead-blasted or brushed (laser-cut); silver PETG for a draft | 169.3 × 113.95 × 1.5 mm |
| Silver bottom plate | [STEP](models/Silver_Bottom_Plate_V2.step) · [STL](models/Silver_Bottom_Plate_V2.stl) | 2.0 mm aluminium sheet, same finish | 169.3 × 113.95 × 2.0 mm |
| Top heat sink | [STEP](models/Heat_Sink_Top_V2.step) · [STL](models/Heat_Sink_Top_V2.stl) | aluminium 6061, machined, natural or clear anodised | 43 × 29.2 × 21.2 mm, 11 fins |
| Bottom heat sink | [STEP](models/Heat_Sink_Bottom_V2.step) · [STL](models/Heat_Sink_Bottom_V2.stl) | aluminium 6061 | 43 × 29.2 × 10.5 mm, 11 fins |
| Selector stem | [STEP](models/Selector_Stem_V2.step) · [STL](models/Selector_Stem_V2.stl) | printed nylon or PETG, or turned aluminium | 10.5 mm dia × 24.3 mm |
| Selector dial | [STEP](models/Selector_Dial_V2.step) · [STL](models/Selector_Dial_V2.stl) | aluminium (engraved, paint-filled) or printed | 14 mm dia × 5.4 mm |
| Power slider | [STEP](models/Power_Slider_V2.step) · [STL](models/Power_Slider_V2.stl) | printed nylon or PETG | 7 × 10 × 23.1 mm |

**Outside:** 184.1 × 128.75 × 34.4 mm; about 39.9 mm tall on 6 mm stick-on feet. Fins stand 2.5 mm proud of the top and bottom faces. Walls 7 mm, top and floor 3 mm, corner radius 9 mm.

## Measured from

- **Board:** `2026-11-08_FPGA_Work/05_HDMI_Extension_Board_V35_Voltage_Holes/project/HDMI_Extension_Board_V35.kicad_pcb` (identical to `~/kicad_work/HDMI_V35/project`). Outline, footprint positions and the one board hole came from the PCB; part heights from its KiCad 3D export (`hdmi_v35.glb`, 270 part boxes in [scripts/hdmi_envelopes_v35.json](scripts/hdmi_envelopes_v35.json)).
- **XEM8310:** the deck's registration on MC1–MC3 (665 part boxes, tallest 18.94 mm above the board bottom). It is an illustrative model and has no fansink.
- **Heights** are from the board's bottom face: floor −9 to −6, silver plate −6 to −4, board 0 to 1.6, lid/base joint 0.7, silver deck 20.9 to 22.4, lid top 25.4.

## Openings (each checked against V35: 39 plug, probe and riser envelopes, none blocked)

| Side | Opening | For |
|---|---|---|
| HDMI side | one recessed bay, 105.7 × 11 mm, with eight 7.3 mm ports in a 1.2 mm wall; numbers 1–8 engraved | J610–J617. A 12 × 8 mm plug overmold fits the bay. |
| Power side | 10.5 mm hole in a 16 mm counterbore | J4, 12 V barrel jack |
| Power side | 9.6 × 3.9 mm port in a 14 × 8 mm pocket | J500, USB-C JTAG |
| Opposite the HDMI side | 14 × 8.6 mm window | XEM8310 USB 3 Type-C |
| Card-edge side | 63.5 × 9.8 mm port | PCIe card edge, reached with a riser (extension) socket. The fingers stay inside the wall. |
| Top | 8 mm hole with the selector dial on it | SW600 JTAG selector, turned from outside (see Selector knob) |
| Top | 3.4 × 8.6 mm guide slot with the slider nub in it | SW601 on/off slide switch, moved from outside (see Selector knob) |
| Top | 29.6 × 12.8 mm window | J900/J901/J902 header holes |
| Top | 62 × 13.4 mm window | J920 voltage test holes (all nine), J910/J911 header holes |
| Top and floor | 13 slots, 2.5 × 40 mm | air over and under the XEM8310 |

- **Mark (Howard, 10 Nov: "make a design out of it, maybe just my initial"):** an HW monogram in a 19 mm ring, with XIE LUAN LAB and HDMI EXTENSION BOARD beside it, engraved 0.5 mm deep on the silver top deck next to the XEM window. It reads through the clear lid from the power (12 V) side. Fill the engraving with dark paint for contrast; the 3D page draws it filled. Port names are engraved on the clear walls.
- **Not opened:** the XEM8310's own DC jack; the board powers the XEM.
- **PCIe in a PC slot:** the box does not fit in a slot. Use a riser cable, or the bare board.

## Selector knob (Howard, 10 Nov: "extension of the turning knob … clean to switch … indicator of which we are switching")

- **What it does:** a stem sits on the SW600 shaft and comes up through the deck and lid; a 14 mm dial on top is turned by hand. The dial carries X (XEM8310) and 1–8 (ports 1–8); the label beside the triangle engraved in the lid is the selected JTAG target. SW600's own detents give the click.
- **Measured from:** SW600 = ALPS SRBQ490100 at (196.0, 56.5) in V35. [ALPS page](https://tech.alpsalpine.com/e/products/detail/SRBQ490100/): 9 positions, 40° per step, 13 ± 5 mN·m, 4 mm D-shaft with 3.0 mm across the flat, tip 9.8 mm above the board top. Nets from the PCB: SEL_0 → U610 (XEM), SEL_1–SEL_8 → U611–U618 (ports 1–8).
- **Stem:** 7.5 mm, D socket 4.15 mm with 0.4 mm above the shaft tip, runs in the 8.0 mm lid hole. A 10.5 mm flange under the deck keeps it captive. Its top is a 9-sided boss.
- **Dial:** 9-sided hole, so it fits in nine positions, and it is engraved on both faces in opposite order. Held by one M2.5 × 6 screw and a 7 mm washer in the stem top.
- **Calibrate once:** which shaft angle is "XEM", and which way the numbers run, are not in the CAD or the ALPS page. With the board powered and the lid on, find the XEM position, then seat the dial with X at the triangle; if the next click is not port 1, flip the dial over.
- **Rule from the schematic:** "Turn OFF before selecting" — slide SW601 off first.
- **SW601 slider (Howard, 10 Nov: "Yes, add it"):** a 3 × 5 mm stem caps the switch's 1.5 mm actuator and stands 3.2 mm proud of the lid as a nub, in a guide slot next to the dial. A 7 × 10 mm flange under the deck keeps it captive. OFF is engraved on the 12 V-wall side and ON on the far side.
  - Measured from V35: SW601 = C&K JS202011JCQN at (184.6, 55.0), actuator 1.5 × 1.5 × 2.0 mm, top 7.21 mm above the board bottom, sliding along board y.
  - ON/OFF sides come from the PCB nets: the pin-1 end (y 57.5) joins ROTARY_COMMON to DGND and MASTER to +3.3 V; the pin-3 end (y 52.5) is OFF_OPEN. This assumes the actuator moves toward the terminals it connects.
  - Travel is assumed 2.0 mm (±1.0); the slot leaves ±1.5. Checked clear of the lid, deck and selector at both ends.

## Heat sinks

"Power source" was taken as the board's 12 V input corner: J4, bulk capacitor C5 and the 5 V module U700 (TPSM63606). The [3 Nov power estimate](../../2026-11-03_FPGA_Work/20_HDMI_Extension_Board_Power_Estimate_And_Plan_V1/START_HERE.md) puts about 1–2.5 W in U700 and milliwatts elsewhere on this board.

| | Top heat sink | Bottom heat sink |
|---|---|---|
| Contact | 8 × 8 mm pedestal over U700 (5.0 × 5.5 mm, top at 5.71) | 8 × 8 mm pedestal on the board underside below U700 |
| Thermal pad gap | 1.0 mm | 1.0 mm |
| Fins | 11 × 1.2 mm, 5.5 mm tall, 34 × 24 mm block | same |
| Clearances | 6.6 mm above C5, 7.8 mm above J4, 3.7 mm beside C5, 2.6 mm above C700–C707 | 2.4 mm below the lowest underside part, 5.9 mm from the J4 pins; no parts under U700 |

- Use a soft, electrically insulating pad (about 1.5 mm, compressed to 1.0).
- The XEM8310's heat (most of the system's 22–44 W estimate) is not handled by these heat sinks. It relies on the XEM's own fansink and the slots; V2 has no fan. V1's 60 mm floor fan can be added back if needed.

## Assembly

1. **Base:** lay the silver plate in the base (posts pass through it). Fit the bottom heat sink from above into the floor opening with a pad on its pedestal; fix it with 4 × M2.5 countersunk screws from below.
2. **Board:** lower the board with the XEM8310 onto the nine posts; the 3.2 mm pin enters the board's 3.5 mm hole at (164.68, 100.05).
3. **Lid:** press six M2.5 heat-set inserts into the lid's wall. Put the selector stem and the power slider up through the deck and lid from inside. Place the top heat sink (pad on its pedestal) and the silver deck inside the lid; 4 × M2.5 countersunk screws from the top go through the lid and deck into the heat-sink flange, and 3 more hold the deck.
4. **Close:** set the lid on the base. Eight pins in the lid stop 0.2 mm above the board. Fix with 6 × M2.5 × 12 screws from below. Add four 12.7 mm stick-on feet about 6 mm tall. Seat the stem on the SW600 shaft and the slider on the SW601 actuator as the lid goes down, then fit the dial and its screw from above.

## Unverified

- **Thermal performance:** no simulation or measurement. Pad choice, U700 case temperature and airflow through the slots are open.
- **Physical fit:** part positions are bounding boxes from the 3D export. Plug overmold sizes (HDMI 12 × 8, USB-C 12.4 × 6.5, barrel 15 mm) and the riser socket (60.5 × 9 mm) are assumed.
- **XEM8310 height:** the model has no fansink. The deck is 13 mm above the XEM board top; measure the real fansink before making parts.
- **Board retention:** V35 has only one board hole, so the board is located by the pin and walls and clamped between posts and lid pins. Not tested against cable pull.
- **SW601 slider:** switch travel, the ON side and the force through a 23 mm stem on a 1.5 mm actuator are not confirmed on a real part. Seating two parts blind while closing the lid may be fiddly.
- **Selector:** dial orientation and direction need the one-time calibration above; socket fit on the real shaft, stem wobble (ALPS allows 0.9 mm at the shaft) and feel through a 20 mm stem are untested. The 2.3 mm dial letters are small.
- **Making it:** 7 mm clear walls, 1.2 mm port wall, insert pull-out in clear resin, and screw threads in 1.5 mm and 2.5 mm aluminium are not checked with a maker. Clear-part finish (polish or coat) decides the look.
- **Close gaps (by design, as V1):** J4 and J500 faces sit at the wall; the XEM DC jack is 0.27 mm from the wall.

Look reference: [Logitech Alto Keys K98M](https://www.logitech.com/en-us/shop/p/alto-keys-k98m.920-013575).

[10 November index](../START_HERE.md)
