# Carrier R13 — Gerald power/ground review

Open `CARRIER_XEM8305_R13_Gerald_Power_Review.kicad_pro` in KiCad10.
Keep this entire project directory together: local libraries, tables and models are required. The three XEM connector models are embedded in the PCB; all other bodies use the included models directory.

Six copper layers; 53 ×83mm; all R12 placements and signal routes preserved. Wider supply copper, local pours and parallel power/ground vias added. R12 is preserved separately.

Native PCB checks: zero physical violations or opens. Four inherited custom-footprint filter warnings appear when every ignored category is enabled. Schematic retains210unused-pin ERC errors and13off-grid warnings. This is a review candidate; physical mating, power/thermal/noise qualification, EEPROM provisioning and functional bring-up remain open.

PCB SHA256:8dbd6be4b25677622cb35d48b56785e9b6b7e0936c5f1011737101005ce17b9f
Schematic SHA256:990217aa5ce830cf300539011fbf7136d92f158808d306037059d009753848e7
