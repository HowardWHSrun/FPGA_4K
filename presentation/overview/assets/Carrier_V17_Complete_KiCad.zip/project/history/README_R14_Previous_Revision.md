# Carrier R14 — general power/ground review

Open `CARRIER_XEM8305_R14_Gerald_General_Review.kicad_pro` in KiCad 10. Keep this entire project directory together: local libraries, tables and models are required. Three XEM connector bodies are embedded in the PCB; the other model references use the included local models directory.

Six copper layers; 53 × 83 mm. All R12/R13 component placements and signal/control routing are preserved. R14 completes the additional C6, USB PHY, C501-ground and connector-bank reinforcement found during the independent general audit. No new circuit components were added.

Every MC1/MC2/MC3 supply/DGND contact reaches multiple vias through shared outer copper. Two constrained D500 ESD tap groups and three low-current DIR5 ties remain single-via exceptions. Some fine-pitch 0.20 mm escapes remain. Do not claim universal two-via pins or qualified current capacity.

Native physical checks and opens: zero. Strict validation retains four inherited footprint-filter warnings. The schematic retains 210 unused-pin ERC errors and 13 off-grid warnings. This is a review candidate, not a fabrication release. Physical mating, current/thermal/noise, ESD/USB/JTAG operation, EEPROM provisioning and factory construction remain open.

PCB SHA256: `05fb81c4c75c09fef54e3d5384e75692f4dd2b78c029711a95bf3864875aa2f7`  
Schematic SHA256: `63e757b709e11bc7bc68f4bf8b8f20f3e458b185ebcd78becadb5730fd2d9cc5`

The README in `history/` describes the preserved previous R13 revision. It is historical, not instructions for the current project.
