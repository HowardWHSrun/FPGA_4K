CARRIER R16 - FABRICATION / DFM REVIEW NOTES - 13 OCTOBER 2026

Design: XEM8305 / LDO carrier; 53 x 83 mm outline centreline; six copper layers; nominal 1.6 mm FR-4.
Requested finish: ENIG, following JLCPCB's reply. Retain accepted J1/J19 0.20 x 0.70 mm lands at 0.40 mm pitch.
Requested copper: 1 oz outer / 0.5 oz inner, subject to confirmation of the exact order-page six-layer stack.
Copper layer order: F.Cu / In1.Cu / In2.Cu / In3.Cu / In4.Cu / B.Cu.
In1.Cu and In4.Cu are DGND reference planes. The original six-layer native stack remains provisional, not an approved factory stack.

USB-C J500: NPTH diameter and centres unchanged. Hole-to-copper minimum is now >=0.25 mm in the saved board.
Two overlapping ground-pad pairs (A1/B12 and A12/B1) have 0.30 mm 45-degree peg-facing corner trims.
This explicitly modifies the supplier-recommended pad shape; approximately 94% of each prior pad area remains.
Pad bounding dimensions, pad centres, contact assignments, all USB data routes and all locating holes remain unchanged.
Review these modified lands in the final production data before fabrication; do not silently trim additional copper.

JP1: preserve the two specified same-net 0.35 mm hole-edge via-to-PTH gaps, accepted in the supplied JLCPCB reply.
Silkscreen: the three affected labels are now >=1.0 mm height / >=0.15 mm stroke.

THERMAL VIA PROCESS: Nonconductive EPOXY FILLED & COPPER CAPPED, IPC-4761 Type VII,
for at least the 13 existing 0.30 mm through-vias identified in Thermal_Vias_Epoxy_Filled_Capped.csv.
These are 9 beneath U10 and 4 beneath U501. Do not replace epoxy with conductive fill by inference from KiCad's generic fill flag.
The CSV gives native PCB coordinates (positive Y down) and matching Gerber/drill coordinates (positive Y up).
The native via records request filled + capped; those booleans do not specify the fill material.
If JLCPCB applies Epoxy Filled & Capped board-wide for its six-layer process, confirm that option at order time.
All other via positions/drills are unchanged. Existing outer mask/paste openings are supplied for review.

Select a supported six-layer 1.6 mm stack and Epoxy Filled & Capped in the actual order.
Select Confirm Production File, as recommended in JLCPCB's reply.
No production order, stack selection or full production-level DFM acceptance is included in this package.
The supplier reply addresses five specific questions only.

CHECKS: retained settings: 0 physical DRC findings, 0 disconnected items, 0 parity findings.
All categories enabled: 0 physical findings, 0 disconnected items, 4 inherited footprint-filter warnings.
Updated independent factory-geometry screen: 0 physical findings and 0 disconnected items.
Unchanged schematic ERC retains 210 unused-pin errors and 13 off-grid warnings; no electrical redesign was made.
Powered function, USB/JTAG operation, thermal performance and populated mating are not established by these static checks.

Origin: Gerbers and metric Excellon PTH/NPTH drills all use the absolute native board origin.
Footprint/model dependencies are project-local in the complete KiCad ZIP.
Source R15 is preserved. This package supersedes R15 only for the documented DFM revision.
