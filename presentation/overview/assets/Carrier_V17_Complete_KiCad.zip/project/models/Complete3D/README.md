# Complete3D model assets

These local models support the R11 carrier's native KiCad 3D view. See [the source and qualification review](../../../verification/Model_Source_Review.md), [the per-reference assignment plan](../../../verification/Model_Assignment_Plan.json), and [the dimension/validity receipt](../../../verification/Dimension_Model_Receipt.json).

Six STEP files are dimension-derived and clearly named `Datasheet`; they are not downloaded production CAD. `SameSky_PJ102AH_Registered.step` is rigidly registered manufacturer CAD. Stock generic package assets retain the [KiCad library license](KiCad_3D_License.md). The existing Hirose and embedded Samtec models retain their own supplier notices. Public model redistribution is not authorized by this local handoff.

The six bare mounting-hole and copper-test-pad features intentionally have no invented component bodies. Exact JP1 header/shunt purchase details remain TBD.
