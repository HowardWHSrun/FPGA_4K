# Carrier R15 — wider power copper

Open `CARRIER_XEM8305_R15_Wider_Power.kicad_pro` in KiCad 10. Keep local libraries, tables and models together. Historical READMEs under `history/` describe earlier revisions.

437 existing power/ground track widths increased. All 81 placements, 298 vias, 720 track centerlines/endpoints, 22 zone boundaries/settings, signal/control/switch/feedback routing and the 53 × 83 mm six-layer board are preserved. Saved fills are recalculated. Both inner DGND reference planes and all formerly shared supply/ground transfer paths remain.

Widths follow clearance and practical circuit/corridor limits. They are not all absolute geometric maxima. Sensitive quiet-ground branches, DIR ties, GNDADC and filtered USB shield routing are unchanged. D500's two single-via ESD groups remain exceptions.

Native physical violations/opens/parity: zero. Strict validation retains four inherited footprint-filter warnings. Schematic retains 210 unused-pin ERC errors and 13 off-grid warnings. This is a static routing review candidate; hardware, factory, thermal/current, USB/JTAG and assembled mating qualification remain open.

PCB SHA256: `61e693734a11f87cc2719fc4030975bb590dee46df228db0d5de3316b03ea035`  
Schematic SHA256: `388cb57d6bd910d850086e8509a7333b7fd0164f908bc5a18d8cf277d7871131`
