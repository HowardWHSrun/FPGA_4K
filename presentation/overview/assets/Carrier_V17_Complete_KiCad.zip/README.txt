CARRIER V17 - SCHEMATIC GRID ALIGNMENT - 14 OCTOBER 2026
Open project/CARRIER_XEM8305_V17_Grid_Aligned.kicad_pro in KiCad 10.
Keep all project-local libraries and models together.

Only 13 schematic grid warnings were corrected: five symbol groups, eight wires,
four attached labels and one branch junction moved coherently to the 1.27 mm grid.
The full native netlist is unchanged: 298 nets and 590 pin memberships.
Fresh ERC: zero endpoint_off_grid warnings. The same 210 intentional unused-pin
findings remain unchanged, unsuppressed and outside this cleanup scope.
Fresh PCB DRC/parity: 0 physical findings, 0 disconnected items, 0 parity findings
under retained V16 settings. All PCB copper, pad nets, placements, vias and saved
plane fills are exactly preserved. Only PCB title/date/version annotation changed.
V16 and every source file remain intact. Prior V16 fabrication notes and thermal-via
process requirements remain applicable. A drawing cleanup does not establish powered
operation, populated mechanical fit or final factory production approval.
