Combined FPGA + eight shared LT3046 LDOs — V7

Open Combined_FPGA_Shared_LDO_V7.kicad_pro in KiCad 10.
30 x 30 mm UNROUTED PLACEMENT STUDY for four 1k boards / eight ASICs.
26.5% less board area than 35 x 35 mm V6; V6 is preserved.
197 footprint records: 181 packaged sites, 15 test pads and one ground net tie.
Eight shared positive LDOs: three front / five back.
Four ASIC DF40 plugs remain grouped underneath.
394 nets and 1204 logical endpoints; all 116 digital functions and 88 recording returns retained.

Five 1.5 V functions remain separate. Other positive outputs are 1.6 V, 0.75 V and +9 V nominal.
Four external negative-feed assignments remain separate.
J10 pin 1 = ASIC_3V3; pin 2 = GND. It feeds seven low-voltage LDOs.
The J10 header can be removed or replaced with an appropriately designed power entry.
The protected FPGA input and ASIC 3.3 V input remain separate in this study.

Zero tracks, vias or zones; 827 native connection gaps remain.
Native ERC and schematic/PCB parity report zero findings.
Independent connectivity, intercomponent copper and copper-edge checks pass.
Canonical DRC retains 491 intrinsic clearance findings, 48 mask bridges and four silk findings.
This is not clean DRC or a fabrication release.

Each LT3046 supports up to 200 mA TOTAL, subject to operating and thermal conditions.
Eight-ASIC rail loads, noise, startup and shared-distribution bypass requirements remain unverified.
FPGA underside support parts were repacked. New routing, decoupling/PDN and thermal copper are required.
The eight-copper-layer / 1.6 mm setting is provisional; HDI construction and populated mate fit remain open.
LT3046 0.25 mm NSMD lands and several 3D bodies are nominal study geometry.
All symbol, footprint and 3D model dependencies are project-local.
See the dated topic START_HERE.md for full evidence and engineering limits.
