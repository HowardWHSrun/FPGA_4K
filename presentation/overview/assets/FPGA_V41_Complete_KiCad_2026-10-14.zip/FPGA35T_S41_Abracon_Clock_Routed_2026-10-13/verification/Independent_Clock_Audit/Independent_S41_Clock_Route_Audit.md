# Independent Abracon clock routing audit

PASS — 199/199 checks.

Target PCB SHA-256: `9b115f6dc2146db157458ca5f9ba8ec0439f61da7359b050244cf347dae1c4c0`.

All original copper, footprint and circuit preservation checks are reported individually in the companion JSON.

| Clock section | P length (mm) | N length (mm) | Difference (mm) | Via span counts symmetric |
|---|---:|---:|---:|---|
| Oscillator to AC coupling | 8.666219 | 8.666220 | 0.000000 | True |
| AC coupling to FPGA | 3.566137 | 3.566137 | 0.000000 | True |

Total P/N planar lengths: 12.232357 / 12.232357 mm; difference 0.000000 mm. Via depths and electrical delays are excluded.

Actual filled-plane sample coverage: 2740/3060 center/width-edge samples in saved reference fill. Every uncovered position is retained in the JSON; sample coverage is not HF return-path qualification.

Whole-board native open count: 445. The rest of the board remains unfinished.

CAD preservation, circuit/polarity/AC-coupling, native saved-copper conductivity, full DRC/ERC and measured planar geometry only. Filled-plane coverage uses actual saved polygons including holes. Samples outside fill are explicitly inventoried, including signal-via antipads. No impedance, jitter, return inductance, electrical propagation, pressed-stack depth, power-source completion or JLC HDI/assembly acceptance is inferred.

Failed checks:
