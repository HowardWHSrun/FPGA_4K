# Abracon clock routing — decisions and checks

The standalone S41 PCB routes the selected 125 MHz Abracon oscillator to the FPGA's dedicated GTP reference input. No circuit or net assignment changed. All 135 footprints remain, with only C78/C79 repositioned and rotated. S40, the separate combined FPGA/LDO project and the XEM8305 carrier are preserved.

## Signal path and Gerald's method

P: Y1.4 → C78.1, then C78.2 → U1.D6. N: Y1.5 → C79.1, then C79.2 → U1.D5. Each retained capacitor is 100 nF; no external parallel termination or clock test-pad branch was added. Y1.2 stays isolated NC.

The oscillator-to-capacitor section runs on L6, between the L5/L7 GND references. After the capacitors, the receiver section runs on L3 over L2 GND. Short bottom pad necks use two adjacent laser stages to L6. The capacitor outputs reach L3 through L8–L7–L6 laser stages and one buried L6–L3 cell. FPGA balls use short 45-degree L1–L2–L3 blind escapes. The complete P/N topology is identical: eight .30/.125 mm laser cells and one .35/.15 mm buried cell per leg. There is no mechanically drilled outer signal barrel at the FPGA.

Clock tracks use cardinal and 45-degree segments. The N-side source-section compensation is one broad trapezoid with a .20 mm flat crown and 45-degree corners. The main coupled L6 corridor uses .10 mm tracks and .15 mm edge gap; the short fanouts and via captures widen the pair spacing as needed for the existing hole/copper rules. Receiver fanouts are separately matched by layer. These dimensions are provisional geometry for the unissued stack, rather than an established 100 Ω impedance result.

Gerald's original instructions cover short blind-via escapes, related-signal matching, return continuity, wider power copper and multiple actual parallel power/GND vias. The source review links the exact original and official AMD/Abracon evidence. Gerald provided no numerical skew budget. The ≤0.1 mm planar matching objective was selected for this CAD revision; it is not a Gerald/AMD timing requirement.

| Section | P planar mm | N planar mm | Difference mm |
|---|---:|---:|---:|
| Y1 to capacitor input | 8.666219331 | 8.666219560 | 0.000000229 |
| Capacitor output to FPGA | 3.566137444 | 3.566137444 | 0.000000000 |
| Combined traces | 12.232356775 | 12.232357004 | 0.000000229 |

Lengths are sums of native trace centerlines on both sides of the capacitors. They exclude via depths, capacitor internal geometry/delay and package delay; geometric matching is not propagation-delay qualification.

## Necessary local adjustments

C78/P moved from [111.0,107.445,0°] to [110.9,107.3,270°]; C79/N moved from [111.0,108.25,0°] to [110.1,107.3,270°], both on B.Cu. Their local pad geometry, nets, identities and circuit values remain intact.

Exactly two horizontal L6 segments were replaced with clean local 45-degree detours. ASIC5_DATA7 gains 0.172396 mm; ASIC6_DATA4 gains 0.082843 mm. Their endpoint and via geometry remains exact and both paths remain conductive. These groups were previously untuned, so these changes do not establish mezzanine timing matching. The hash-bound before/after AST declaration is retained in `verification/Issued_Local_Signal_Delta.json`; every other original segment and all 751 original vias are unchanged.

## Supply and return paths

Y1 VDD/OE and C80/C81 now reach U3's actual 1.8 V output and C13 output capacitor. The output-sense connection is kept separate to C13. The feed uses .50 mm copper in the open corridor and .35 mm through the connector-shell corridor; local connections have genuine parallel via columns. U3/C13 and Y1/C80/C81 grounds reach the retained filled references. This closes the local clock supply loop, not the entire board PDN.

New full L2/L5/L7 GND transfers sit at [104.0,104.0], [104.0,105.6], [109.8,106.5] and [110.8,107.85]. Source B↔L6 transition distances to these transfers are approximately 0.50–1.17 mm. The post-capacitor B↔L3 cores have transfers 0.50 mm and 1.30 mm away. F↔L3 escapes keep the same L2 reference; distances to a full three-plane transfer are not an independent requirement there.

Actual saved reference copper was checked, including holes, rather than zone outlines alone. Every L6 center/width-edge sample is covered by L5 GND. Across all clock layers, 320 of 3060 samples lie outside reference copper near signal-via antipads; each is within 0.266 mm of a clock via, with positions retained in `Reference_Antipad_Proximity.json`. All three reference zones remain single filled subpolygons. This evidence does not measure return inductance or certify high-frequency performance.

## Verification and remaining work

The final PCB SHA-256 is `9b115f6dc2146db157458ca5f9ba8ec0439f61da7359b050244cf347dae1c4c0`.

Independent audit: 199/199 PASS. It verifies the exact 220-net/806-endpoint circuit, all four clock sections, AC isolation, polarity, local supply/GND, all 116 mezzanine paths, each native copper/pad net against its saved text, rigid capacitor movement, the narrow two-net delta, all other original copper and actual reference-fill provenance. A separate private shadow of the 23 remaining source escapes passes 14/14 and native DRC/parity; those escapes are not routed in the actual S41 file.

Native physical DRC/parity: 0 errors/0 mismatches. ERC: 0 errors and the inherited reserved-analog warning. All 51 visible DRC warnings are co-located staged holes; no rule, severity, netclass, global library or ignore setting changed. Actual project: 1893 segments, 813 vias, three filled GND zones and 445 whole-board native opens.

Exact JLCPCB 2+4+2 HDI fabrication/assembly acceptance, pressed stack and impedance, 1.8 V oscillator jitter, full timing/SI/PDN and the rest of the board routing remain open. Static CAD checks do not qualify assembled-board function or authorize fabrication.
