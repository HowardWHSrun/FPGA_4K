# Standalone FPGA S41 — Abracon clock routed

13 October 2026. **Routing checkpoint; not a fabrication release.** Board outline remains 25 × 23 mm. The separate combined FPGA/LDO and XEM8305 carrier projects are unchanged.

Open [the complete KiCad project](project/FPGA35T_Scratch_Step41_Abracon_Clock_Routing.kicad_pro), then its [PCB](project/FPGA35T_Scratch_Step41_Abracon_Clock_Routing.kicad_pcb). [S40](../05_FPGA_Abracon_Clock_Step40/START_HERE.md) remains the preserved pre-routing source.

Y1 AX3DCF1-125.0000T3 is routed through C78/C79 to the dedicated FPGA GTP reference-clock input. Local enable, supply, bypass and ground connections are also routed. The two capacitors now sit side by side on the bottom. Two local L6 mezzanine trace detours clear the new clock transitions; every original via and all other original trace geometry remain exact.

| Check | Result |
|---|---|
| P / N planar trace length | 12.232357 / 12.232357 mm; difference <0.001 mm |
| Clock endpoint and polarity checks | All four sections connected; NC isolated; series AC coupling preserved |
| Transition construction | Same eight adjacent laser stages plus one buried L3–L6 cell per complete leg; no signal through-board barrel |
| Existing digital mezzanine connections | 116/116 connected, with no assigned loose copper |
| Native physical DRC / schematic parity | 0 errors / 0 mismatches |
| Native ERC | 0 errors; one inherited reserved-analog warning |
| Independent audit | 199/199 PASS |
| Remaining 23 source escapes | Separate private shadow: 14/14 PASS; they remain unrouted in the actual project |

The 51 co-located-hole warnings describe the staged HDI construction and remain visible. The whole board still has 445 native open connections. Full routing, full PDN, timing/SI, clock jitter at 1.8 V and exact JLCPCB HDI/assembly acceptance remain open. The nominal 100 Ω differential target is not qualified by these CAD checks.

- [Routing decisions and measurements](Clock_Routing_Summary.md)
- [Gerald and manufacturer routing source review](reviews/Clock_Routing_Method_Primary_Sources.md)
- [Independent final audit](verification/Independent_Clock_Audit/Independent_S41_Clock_Route_Audit.md)
- [Future-source reservation check](verification/Future23_Source_Shadow_9b115f6dc214_Exact_AST/Future23_Source_Shadow_Check.md)
- [Exact two-net routing delta](verification/Issued_Local_Signal_Delta.json)
- [Eight native copper-layer SVG previews](previews/)
- [Portable complete KiCad bundle](FPGA35T_S41_Abracon_Clock_Routed_2026-10-13.zip)
