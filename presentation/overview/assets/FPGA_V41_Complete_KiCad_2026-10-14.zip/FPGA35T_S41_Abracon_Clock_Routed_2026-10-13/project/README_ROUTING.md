# S41 — Abracon clock routing

Open `FPGA35T_Scratch_Step41_Abracon_Clock_Routing.kicad_pro` in KiCad 10. S40 and all earlier native projects remain preserved.

Y1 AX3DCF1-125.0000T3 is routed through the retained 100 nF C78/C79 capacitors to U1 D6/D5. Clock source routing uses L6, then the AC-coupled receiver routing uses L3 with short adjacent laser and buried-core transitions. Both complete legs have identical via sequences and approximately 12.232357 mm planar length. Geometry is provisional for the unissued HDI stack; it is not a qualified 100-ohm impedance result.

The two clock capacitors moved to a parallel bottom arrangement. Exactly two local L6 mezzanine segments were replaced with clean 45-degree detours to clear the clock transitions. All 116 digital mezzanine paths remain connected. Local Y1 enable/VDD/C80/C81 supply and ground are connected to U3/C13 and the retained ground references.

See `../START_HERE.md`, the exact local delta and the independent verification receipts. Full board routing, complete PDN, clock jitter at 1.8 V, timing/SI and exact JLCPCB HDI/assembly acceptance remain open. This is a routing checkpoint, not a fabrication release.
