# Artix Frontend V37 · edited 5 Nov 2026, 08:30 CST: fabrication and assembly definition

**Status:** this package is a request for JLC's review. It is not an approved build, and the board is not fabrication-ready until JLC accepts the stack and the via schedule below.

**Source files:**
- PCB `Artix_Frontend_V37.kicad_pcb`, SHA-256 `897061230ebc06b69080e79bfab8dcb878802e7aba12ff1ce37bbdcb411c230b`.
- Schematic SHA-256 `6a5518a9d48ed51e9a0289c8f5b84fd0ce5f3774a37392607460ebd855d30986`.
- Everything was exported with KiCad 10.0.6 `kicad-cli` from that project.

**Change from V36:** one routing fix. BOOT_RAILS_PG_3V3 on L1 moved north so its edge gap to GTP_TX0_P is 0.265 mm (was 0.128 mm; 3W screen 0.22 mm). Seven unlocked PG segments changed; GT copper, parts, positions, nets, vias, zone fills, BOM and placement are identical to V36. Only the L1-Top Gerber differs; all drill files are identical to V36. The schematic changed only in its title block.

**Native check:**
- DRC: 0 errors, 0 open connections, 0 schematic mismatches.
- 0 DRC warnings. The 164 intended stacked-via spots are DRC exclusions in the project file, each with a note.
- ERC: 0 errors, 8 same-name label warnings.

## 1. Board

| Item | Value |
|---|---|
| Size | 22.59 × 25.42 mm; stepped outline (notch at the top-left) |
| Layers / thickness | 10 copper layers, 1.6 mm nominal, 1 oz (35 µm) on every layer |
| Finish | ENIG. JLC offers no HASL on HDI or ≥6-layer boards, and the 0.5 mm WLCSP and 0.8 mm BGA need a flat finish |
| Solder mask / silk | Both sides |
| Parts | 185 footprints: 60 top, 125 bottom (171 SMD placements); double-sided assembly |
| Smallest parts | 0201 R/C on both sides; U1 0.8 mm BGA (Artix-7 CSG324); U7 0.5 mm WLCSP; SOT-886/USON-6/SOT-563 logic |
| Minimum track / space | 0.09 mm / 0.09 mm (local HDI rules around U1 and the via families); 0.10 mm / 0.10 mm elsewhere |
| Copper to board edge | ≥ 0.50 mm |

## 2. Stack (as drawn in CAD; dielectric material still provisional)

| Layer | Role | Thickness below it |
|---|---|---|
| L1-Top | parts, fan-out, GT pairs | prepreg 0.09 mm |
| L2-GND | ground plane | prepreg 0.09 mm |
| L3-Signal | routing | core 0.20 mm |
| L4-GND | ground plane | prepreg 0.09 mm |
| L5-Power | VCCINT, VCCO, MGTAVCC, MGTAVTT, VIN_3V3 islands | core 0.31 mm |
| L6-VCCAUX | VCCAUX pour and 13 slow signals | prepreg 0.09 mm |
| L7-GND | ground plane | core 0.20 mm |
| L8-Signal | routing | prepreg 0.09 mm |
| L9-GND | ground plane | prepreg 0.09 mm |
| L10-Bottom | parts, fan-out | — |

**Target JLC stack:** JLC's impedance calculator lists **JLCH101611Y2-2313**. It is a 10-layer, 1.6 mm, 1/1 oz, 2-step stack with buried vias, using 0.089 mm 2313 prepreg on L1–L2, L2–L3, L8–L9 and L9–L10 and 0.20 mm cores. Its finished thickness is 1.54 mm ±10 %.
- We ask JLC to confirm that stack, or name the closest one, and to give the pressed thickness of every dielectric.
- We will then re-solve the 100 Ω differential pairs:
  - GTP TX0–TX2 and the 125 MHz reference clock;
  - currently 0.11 mm wide with a 0.20 mm gap.

## 3. Via schedule (all vias filled and capped)

The CAD board setup now says `(filling yes) (capping yes)`, i.e. IPC-4761 Type VII, for every via.

| Family | Hole / land | Count | Drill file | Treatment requested |
|---|---|---:|---|---|
| L1–L2 laser | 0.10 / 0.25 mm | 440 | `Artix_Frontend_V37-L1-L2.drl` | copper-filled, planarised (≤ 25 µm dimple), solderable when in a pad |
| L2–L3 laser | 0.10 / 0.25 mm | 411 | `-L2-L3.drl` | copper-filled (stacked on L1–L2 and on the L3–L8 cap) |
| L3–L8 buried mechanical | 0.15 / 0.30 mm | 500 | `-L3-L8.drl` | resin-plugged and copper-capped; laser vias land on the caps |
| L8–L9 laser | 0.10 / 0.25 mm | 400 | `-L8-L9.drl` | copper-filled |
| L9–L10 laser | 0.10 / 0.25 mm | 414 | `-L9-L10.drl` | copper-filled, planarised, solderable when in a pad |
| L1–L10 through | 0.15 / 0.35 mm | 5 | `-L1-L10-PTH.drl` | epoxy-filled and capped (POFV) |
| J3 shell slots | 0.65 mm plated slots | 4 | `-L1-L10-PTH.drl` | plated, not filled |

**Via sites and stacking:**
- **Totals:** 2,170 via objects at 1,027 XY sites.
- **Sites by stack depth:**

  | Levels | Sites |
  |---:|---:|
  | 1 | 345 |
  | 2 | 280 |
  | 3 | 353 |
  | 4 | 39 |
  | 5 | 10 |

- **Stacked vs staggered:** stacked vias sit exactly on top of each other. No staggered pairs are intended.

**Via-in-pad:**
- 288 vias sit inside small-part SMD pads, and 6 inside U1 ball pads.
- One of the U1 ones is a through via in ball A5 at (112.620, 106.250).
- These pads need the planarised fill above.

**Drill files:**
- KiCad's original names map as: front-in1 → L1-L2, in1-in2 → L2-L3, in2-in7 → L3-L8, in7-in8 → L8-L9, in8-back → L9-L10.
- `drill_report.txt` uses the original names.

## 4. Assembly, panel and fiducials

- **Process:** JLC Standard PCBA, double-sided. X-ray U1 and U7.
  - Suggested side order: solder the bottom first. It has more but smaller parts.
  - Let JLC decide the side order for this exact mix.
- **Fiducials:**
  - There is no room on the board for a 1 mm copper / 2 mm mask fiducial. The largest clear circle is 1.08 mm radius at one spot on top, and ≤ 0.91 mm elsewhere.
  - Put fiducials on the panel rails, three per rail, on both faces.
- **Panel:** the board is under JLC's 70 × 70 mm assembly minimum. Two options:
  - (a) ask JLC to add rails and fiducials;
  - (b) a 3 × 2 array with 2 mm routed gaps and mouse-bite tabs (≥ 2 tab sets per board edge ≤ 30 mm). The rails are 8.6 mm top and bottom so the panel reaches 71.8 × 70.0 mm, each rail has three 1 mm fiducials per face, and four 2.0 mm NPTH tooling holes go at the rail corners.
  - Mill the top-left notch, which cannot be V-cut.
- **Edge spacing:** parts sit closer than JLC's 2.5 mm body-to-edge guideline in places, for example the south test-pad row and J3. Ask whether that is acceptable with rails attached.
- **Mounting:**
  - There are no holes: no spot has a clear column through all 10 layers.
  - Support the board by its two DF40C-70DS receptacles plus an edge frame or clamp in the enclosure.
  - The copper keeps 0.5 mm from every edge.
  - Hirose DF40 guideline ETAD-H1015-00 §1.1.4–1.1.7 covers mating accuracy and board stabilisation.

## 5. Questions for JLC (please answer before order)

1. Accept the 2-step HDI with buried L3–L8 vias:
   - laser 0.10/0.25 mm stacked laser-on-laser and laser-on-buried-cap;
   - buried 0.15/0.30 mm.
   Both are at your published minimums. Which stack ID?
2. Your HDI rules say "via edge to trace ≥ 0.15 mm". Is "via edge" the drilled hole or the land? Our land-to-track gaps are 0.09–0.10 mm under local rules.
3. Confirm copper-filled, planarised laser vias inside 0201 pads and BGA ball pads (288 + 6) are fine for SMT, and the flatness you guarantee.
4. Impedance control on L1, L3 and L8 for 100 Ω differential pairs with your stack. Please return width and gap.
5. Standard PCBA on this 10-layer HDI board:
   - 0201 parts on both sides;
   - an 0.8 mm BGA and an 0.5 mm WLCSP (does it count as a BGA for spacing?);
   - 70 same-side part pairs closer than your SMD spacing table, mostly bypass capacitors within 1 mm of their IC.
6. Panel: will you add rails, fiducials and tooling holes to this stepped outline (mouse bites, milled notch), or should we supply option (b)?
7. Parts not in the JLC library, to be sourced or consigned:
   - R10 Panasonic ERA-1AEB132C;
   - R13 Vishay TNPW02012K49BEED;
   - U7 Winbond W25Q128JWYIQ (WLCSP).
   - U11 74AUP2G07GM,115: JLC had 29 in stock on 4 Nov 2026. TI SN74AUP2G07DRYR is the approved alternate.

## 6. Files in this package

- `gerbers/`:
  - 10 copper layers, both masks, pastes and silks, and Edge.Cuts;
  - `Artix_Frontend_V37-job.gbrjob`.
- `drill/`:
  - one Excellon file per layer pair, plus PTH and NPTH;
  - a PDF map for each;
  - `drill_report.txt`.
- `assembly/`:
  - `Artix_Frontend_V37_bom.csv`, grouped by value, footprint and MPN;
  - `Artix_Frontend_V37_pos.csv` (KiCad) and `Artix_Frontend_V37_CPL_JLC.csv` (JLC column names, mm).
- `Artix_Frontend_V37_schematic.pdf`.
