# Source and model notices

Project sources retain their existing ownership; no new license is granted. Standard KiCad library portions retain their original authorship and applicable KiCad library license/exception. Samtec model payloads are not distributed in this archive.

Sources: https://github.com/KiCad/kicad-footprints/blob/master/LICENSE.md and https://www.samtec.com/about/legal/ .

Nominal model shapes and CAD checks do not qualify populated fit or operation.
