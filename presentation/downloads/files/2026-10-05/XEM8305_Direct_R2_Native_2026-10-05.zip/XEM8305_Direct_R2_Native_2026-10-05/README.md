# XEM8305 direct routing-board native review · R2

5 October 2026. Extract the whole archive and open `hardware/LDO_to_XEM8305_Direct_R2.kicad_pro`. The project, four-sheet schematic hierarchy, board and local symbol/footprint libraries are included.

Research revision; routing and engineering status follow the accompanying check summary. This package does not establish fabrication, mating, rail/timing qualification or operating firmware.

The public copy preserves native electrical/layout semantics. Restrictive embedded Samtec model payloads were omitted and their references externalized; original/public hashes and exact omissions are in `PACKAGE_MANIFEST.json`. The original source CAD is unchanged. Complete assembled manufacturer 3D bodies are not bundled.
