# External connector models

Samtec ERF6 model payloads are intentionally omitted from this public copy. Source them under the applicable manufacturer terms for local 3D use; native electrical and footprint pad/layout content remains present. The standard KiCad library model directory is also an external installation dependency.
