# R39 complete KiCad project — research revision, not for fabrication

Open `hardware/FPGA35T_V15.kicad_pro` with KiCad 10.0.6. Keep this whole
directory together, including libraries and hardware/3dmodels.

Current 5 October 2026 XC7A35T-2CSG325I revision, 41 × 41 mm. R39 retains
323 supplier-supported land corrections and improved silkscreen, adds bounded
FPGA escape rules and corrects 31 component fields on 11 parts. The remaining
512 narrow TI/Hirose lands retain accurate supplier geometry, corroborated by
JLCPCB's exact-part library. Board-specific manufacturing acceptance is pending.

Fresh native physical DRC, ERC and schematic/PCB parity pass under the delivered
settings. All 343 component poses, 2,135 pads/nets and 113 existing tracks are
preserved from R38. Native connectivity has 1,413 PCB connections awaiting
copper; 499 is the capped DRC listing. The schematic assignments are intact.
No vias or copper planes are placed. One zone object is a non-copper rule area.

The eight-layer 3+2+3 HDI and 0.35/0.125 mm adjacent laser cell are engineering
candidates. Native 1.6 mm thickness is an inherited CAD placeholder, not an
issued factory schedule. Critical routing, impedance, power/return paths,
implementation timing and populated qualification remain incomplete.

All 18 schematic sheets, project rules, local symbols/footprints and 34 model
assets are included. All 315 placed model references resolve locally; 28
intentional copper-only footprints have no bodies. Unused helper footprints
may refer to installed KiCad stock models. Nominal visualization models do not
certify exact purchased-part tolerances or assembled fit.

`MANIFEST.json` records exact native file bytes and source SHA256s.
`CHECK_SUMMARY.json` records check results and ignored checks.
`MODEL_PROVENANCE.json`, `THIRD_PARTY_NOTICES.md` and `licenses/` retain source
attribution and terms. Native CAD/library/model bytes are unchanged. No
internal scripts, private notes/correspondence, supplier reference PDFs/HTML,
editor preferences, caches or unrelated projects are included. Earlier R37,
paused R35 and most-routed R34 are separate engineering revisions.

Project-specific material retains its original ownership; no new open-source
license is invented. KiCad library portions retain CC-BY-SA 4.0 with the KiCad
exception and original notices. Restricted OEM Hirose reference STEP is absent.
