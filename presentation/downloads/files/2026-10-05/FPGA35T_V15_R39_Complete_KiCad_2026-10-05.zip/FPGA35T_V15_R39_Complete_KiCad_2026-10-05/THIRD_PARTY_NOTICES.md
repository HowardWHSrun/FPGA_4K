# Source attribution and distribution limits

The project-specific native design, symbols, footprint adaptations and drawing-derived nominal models are retained from the dated source project and are prepared for sharing under Howard's explicit publication authorization. Original ownership is retained. No new broad public or open-source license has been invented for these custom files.

KiCad community library/model portions are licensed under CC-BY-SA 4.0 with the KiCad electronic-design and generated-files exception. Source STEP copyright/license comments are preserved, including the E5 JST model by Frank Severinsen (2018). See `licenses/KiCad_Libraries_LICENSE.md`. Redistribution of library collections retains attribution and share-alike terms. Public library source: https://gitlab.com/kicad/libraries/ .

R39 visualization models include independently authored drawing-derived nominal packages and verified KiCad stock package models. Restricted OEM Hirose reference STEP files, and other manufacturer reference downloads, are excluded. Source geometry assumptions are summarized in `MODEL_PROVENANCE.json`; supplier-certified fit/tolerance is not inferred.

The package includes no third-party datasheet PDFs, unrelated source archives, internal notes, correspondence, credentials or software runtime caches.
