# Omitted Samtec connector models

The embedded ERF6-40-03_5-L-DV-A-K-TR.stp and ERF6-50-03_5-L-DV-A-K-TR.stp payloads are omitted from this public copy. Their model references use this relative directory. Obtain any local models under the manufacturer terms; the files are deliberately absent. Numbered pads, holes, placement, all copper and schematic topology remain present and unchanged.

Standard KiCad models use ${KICAD10_3DMODEL_DIR} and require a normal KiCad10 library installation. No external supplier STEP/GLB file is bundled. The locally authored Murata envelope is included separately and is nominal.
