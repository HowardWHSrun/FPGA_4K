# XEM8305 direct carrier R3 - native review package

5 October2026. Extract the whole archive and open hardware/LDO_to_XEM8305_Direct_R3.kicad_pro in KiCad10.0.6 or later. The PCB, all8 schematic sheets, project settings, relative library tables, local symbols/footprints and locally authored Murata nominal envelope are included.

The sole external12V input feeds local2.5V/3.3V converters. All3 XEM expansion connectors and both original-LDO mating sockets are retained. All23 ASIC signals pass through the implemented isolation channels. MC3 contains28 ground and52 reserved NC contacts; high-speed use is not implemented.

The frozen source PCB SHA256 is6e1cde48c3a146e691005f6e76434e98ce9298ac09ed0b13a128e490fa048e78. Samtec embedded3D model bytes are omitted and references are relative external placeholders. PACKAGE_MANIFEST.json records source/public hashes and exact omissions; electrical/layout content remains unchanged. Original source CAD is not modified.

This is a prototype/review package with separately checked Gerber output. Local CAD checks are not factory DFM approval, actual simultaneous connector seating, physical rail/timing/thermal qualification or tested operating firmware. Standard KiCad3D models remain an installation dependency.

The accompanying published schematic PDF uses a documented print-only layout copy: a larger root page separates hierarchy boxes, repeated power-flag captions are consolidated, selected TMUX fields are moved and the displayed revision is shortened. Component values, UUIDs and all circuit nets are identical to this unchanged native schematic; public-package fresh checks and print-copy topology parity are recorded in PUBLIC_VALIDATION_SUMMARY.json. These PDF annotation adjustments are not native hardware edits.
