# XEM8305 / LDO carrier — C4.8-R4 public KiCad package

Packaged 2026-10-09. Extract this entire ZIP and open `project/CARRIER_XEM8305_C4_One_Page.kicad_pro` in KiCad 10. Keep the project-local libraries and library tables together.

This four-layer routing review revision has the aligned corner vias: 53 × 83 mm, 28 footprints, 379 track segments and 171 vias. The canonical saved R4 source PCB SHA-256 is `ac7dd0c9bd0ba2be19fcc2c04cfb4026a67434b36835d43b3acdce32c8e4b020`. Its inherited PCB title-block label remains `C4.8-R3`; this public derivative retains that source metadata. The package identity and source hash identify the R4 routing revision.

The public copy omits only the embedded Samtec ERF6-40-03_5-L-DV-A-K-TR.stp and ERF6-50-03_5-L-DV-A-K-TR.stp model payloads and changes their model references to `project/models-external/`. Those optional body models are deliberately absent. Obtain models under the manufacturer terms for local 3D use. Standard Hirose body models remain references to the installed KiCad 10 3D library. Symbol libraries, footprints, pads, placement, copper, schematic and rules are retained. `PACKAGE_MANIFEST.json` records every source/public hash and every omitted payload instance.

The recorded R4 PCB checks have zero DRC violations, opens and schematic/PCB parity findings. Existing schematic ERC findings and electrical/mechanical qualification remain open. This is a review package, not a fabrication release. No FPGA-from-scratch project, editor/session settings or private local paths are included.
