# Carrier C4.8-R4 — Gerber and drill review export

Exported 2026-10-09 with KiCad 10.0.6. This is a routing review export, not a fabrication release.

Contents: four copper layers, front/back solder mask, front/back silkscreen,
front/back solder paste, Edge.Cuts, Gerber job file, separate plated/unplated
Excellon drill files in millimetres, drill-map PDFs and drill report.
Gerbers and drills use the same absolute coordinate origin. No mirroring is applied.
Solder-mask openings are subtracted from the silkscreens.

Layer order: F.Cu / In1.Cu / In2.Cu / B.Cu. In1 is the DGND reference plane;
In2 is DGND with the retained converter sense trace. Board outline centerline
is 53 x 83 mm. The job's 53.05 x 83.05 bounding box includes the 0.05 mm outline stroke.
The saved nominal thickness/stackup is design metadata, pending fabricator agreement.

Source PCB SHA-256:
ac7dd0c9bd0ba2be19fcc2c04cfb4026a67434b36835d43b3acdce32c8e4b020

The source PCB retains an inherited C4.8-R3 title revision. An export-only copy
corrects that single title field to C4.8-R4; all other PCB bytes are identical.
The active design and supplied KiCad ZIP are unchanged.

The source revision's native PCB checks report zero violations, opens and
schematic/PCB parity findings. Existing schematic ERC cleanup, electrical/timing,
stacked mechanical fit and manufacturing qualification remain open.

Drills: 179 plated holes (171 vias plus 8 through-hole component pads),
6 unplated locating holes. Refer to Drill_Report.txt and the included maps.
