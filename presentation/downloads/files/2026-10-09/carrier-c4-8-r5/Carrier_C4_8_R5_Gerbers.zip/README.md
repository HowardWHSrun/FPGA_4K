# Carrier C4.8-R5 — Gerber and drill review export

Exported 2026-10-09 from the current saved PCB without edits. TP21 is removed.
Four copper layers: F.Cu / In1.Cu / In2.Cu / B.Cu. Both inner layers provide DGND reference; In2 retains the converter sense trace. Original outline centerline 53 × 83 mm. Job bounding dimensions include the 0.05 mm edge stroke.

Includes four copper layers, front/back mask, silkscreen and paste, Edge.Cuts, job metadata, separate plated/unplated Excellon drills, map PDFs and drill report. Gerbers/drills share absolute origin with no mirroring. Silkscreen excludes solder-mask openings.

The source PCB checks report zero violations, opens and schematic parity findings. Inherited schematic ERC findings, electrical/thermal/timing, stack fit, fabrication stackup and factory acceptance remain open. Review export; not a fabrication release.

Source PCB SHA-256: a26d5b67a5cbc5c3e4e6b16d28f7e0fba73bdf0f8ddd29d4a6af205f580d3cf2
