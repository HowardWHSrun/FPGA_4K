# XEM8305 / LDO carrier — C4.8-R5 public KiCad package

Packaged 2026-10-09. Extract this entire ZIP and open `project/CARRIER_XEM8305_C4_One_Page.kicad_pro` in KiCad 10. Keep the project-local libraries and library tables together.

This four-layer routing review removes TP21 and retains the aligned corner vias: 53 × 83 mm, 27 footprints, 379 track segments and 171 vias. The canonical saved R5 source PCB SHA-256 is `a26d5b67a5cbc5c3e4e6b16d28f7e0fba73bdf0f8ddd29d4a6af205f580d3cf2`. Its PCB title revision is C4.8-R5. The package manifest records the exact current source hash.

The public copy omits only the embedded Samtec ERF6-40-03_5-L-DV-A-K-TR.stp and ERF6-50-03_5-L-DV-A-K-TR.stp model payloads and changes their model references to `project/models-external/`. Those optional body models are deliberately absent. Obtain models under the manufacturer terms for local 3D use. Hirose J1/J19 supplier STEP files are omitted under their redistribution restrictions. The exact connector part values, footprint geometry and project-relative model transforms remain in the native files. Obtain optional local models using `project/models/Hirose/README.md`. Symbol libraries, footprints, pads, placement, copper, schematic and rules are retained. `PACKAGE_MANIFEST.json` records every source/public hash and every omitted payload instance.

Power connections: the 12 V barrel input feeds the XEM8305 VDCIN pins directly. The carrier converter supplies 3.3 V to the LDO/ASIC board at J1 pins 1/2 through JP1. The XEM module's own 1.8 V output feeds its I/O-bank VCCO pins. The carrier does not supply 3.3 V to XEM VDCIN.

The recorded R5 PCB checks have zero DRC violations, opens and schematic/PCB parity findings. Existing schematic ERC findings and electrical/mechanical qualification remain open. This is a review package, not a fabrication release. No FPGA-from-scratch project, editor/session settings or private local paths are included.
