# Optional Samtec 3D body models

The public package deliberately omits these supplier STEP files:

- ERF6-40-03_5-L-DV-A-K-TR.stp
- ERF6-50-03_5-L-DV-A-K-TR.stp

PCB and footprint model references point to this directory. Obtain any local copies under the manufacturer's applicable terms. Missing bodies affect optional 3D display; all native footprint pads, holes, placement and copper remain available. Standard KiCad model references require the normal KiCad 10 3D library installation.
