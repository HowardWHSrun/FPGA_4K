# Optional Hirose mezzanine models

No Hirose STEP binaries or derivative model previews are included. Download these models directly under Hirose terms for local use. Preserve their bytes and use the native model transforms already assigned in the PCB and local footprints.

J1: DF40C(2.0)-50DS-0.4V(51), CL0684-4091-0-51
https://www.hirose.com/en/product/p/CL0684-4091-0-51
Save the downloaded DF40C(2.0)-50DS.stp as DF40C_2p0_50DS_0p4V_Hirose.stp in this folder.

J19: DF40C(2.0)-24DS-0.4V(51), CL0684-4041-2-51
https://www.hirose.com/en/product/p/CL0684-4041-2-51
Save the downloaded DF40C(2.0)-24DS-0.4V.stp as DF40C_2p0_24DS_0p4V_Hirose.stp in this folder.

Missing model bodies affect optional 3D display only. Native pads, holes, footprint positions, copper and circuit remain available. Hirose identifies its 3D data as simplified; the latest 2D drawing controls.
