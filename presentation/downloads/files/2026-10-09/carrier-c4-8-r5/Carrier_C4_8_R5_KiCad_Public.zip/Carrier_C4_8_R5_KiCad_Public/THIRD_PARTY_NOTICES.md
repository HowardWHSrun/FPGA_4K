# Source and model notices

Project sources retain existing ownership; no new blanket license is granted. Standard KiCad library portions retain their original authorship and CC-BY-SA 4.0 license with the library exception. The preserved license text is in `licenses/KiCad_Libraries_LICENSE.md`.

Samtec embedded/external STEP and Hirose J1/J19 STEP models are omitted; no supplier model redistribution permission is claimed. Supplier footprints and project geometry are retained as native design data under existing attribution. Source: https://www.samtec.com/about/legal/ .

Standard KiCad model paths refer to the user's installation and are not payload copies. KiCad license source: https://github.com/KiCad/kicad-footprints/blob/master/LICENSE.md .
