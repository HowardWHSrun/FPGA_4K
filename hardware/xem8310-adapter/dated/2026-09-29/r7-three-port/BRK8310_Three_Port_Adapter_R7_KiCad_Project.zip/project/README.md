# R7 KiCad project

Open `BRK8310_Three_Port_Adapter_R7_Candidate.kicad_pro` with KiCad 10. The five schematic sheets and local `libraries/AdapterR7.kicad_sym` must remain beside this file. `sym-lib-table` points to that local library.

No PCB or physical footprints are included. The MC3 symbols represent all 80 numbered signal contacts, but the ground paddle/mechanical stack is still unresolved. MC2 1-8 are netlisted; all MC1 1-80 and MC2 9-80 pass-through contacts are not yet netlisted. B1-B3 are circuit requirements, not chosen protection devices. J201-J203 are the candidate adapter Type-D receptacles; BRK J1 in signal names refers to the separate existing Bulls Eye footprint.

Use the parent [handoff](../START_HERE.md) for the exact mapping, sources, status, and validation scope. **Do not use this candidate for PCB layout or fabrication.**
