# XEM8310 adapter R2 — 12 V selected

Open `XEM8310_MicroHDMI_Adapter_R2_12V.kicad_pro` in KiCad 10. Keep all three sheets, `sym-lib-table`, and `libraries/AdapterR2.kicad_sym` together.

R2 records the user's 12 V cable-supply decision. J2 micro-HDMI pin 19 is named `12V_SELECTED` and its net is `CABLE_12V_RESERVED`. Its intended load includes the custom FPGA, routing board and ASICs. The contact is electrically isolated except for its label: no power source, protection circuit or current budget has been implemented.

All data, ground and JTAG connections retain the R1 architecture. This remains an electrical connection draft without PCB, assigned footprints or fabrication readiness.

## Sheets

1. Three recording pairs and one return command pair connect the custom micro-HDMI to XEM MC3 GTY bank 226. The custom FPGA board already contains eight 100 nF coupling capacitors; none are duplicated here.
2. Separate generic probe interfaces serve the custom FPGA and XEM FPGA. XEM JTAG uses MC2; its general 1.8 V reference is MC1.2. The probe pin order is custom and not plug-compatible with HS2/HS3. Probe reference loading remains to be verified.
3. Remaining MC1/MC2/MC3 carrier contacts are explicitly marked NC, with unused GTY receiver and clock-buffer requirements noted.

## Sources and reproduction

Primary-source evidence remains preserved in [the R1 source archive](../../02_XEM8310_Adapter_R1/review/). The prior R1 project is unchanged.

Run `python3 ../scripts/build_schematic.py` from this directory to regenerate this R2 project. This overwrites generated R2 schematic files, so preserve manual edits first.

The rendered PDF, native netlist and ERC report are in `../validation/`. Power source, protection, load budget, cable qualification, physical connectors and layout still need design work.
