# FPGA100T Mezzanine Study — review only

Open `hardware/FPGA100T_Mezzanine_Fit.kicad_pro` in KiCad. Keep this complete extracted folder together. Custom footprint libraries are included; generic 3D model assets from the KiCad installation are not bundled.

128-component placement study; 383 existing-net unconnected items in fresh native DRC. All tracks/vias/zones are removed and all 120 numbered mezzanine contacts have no assigned net. There is no integrated schematic or FPGA-ball allocation. C92/R122 from the rail revision are not present. Footprint mating geometry and the J4 board-edge placement remain unresolved. The library table has been made relative only in this package; native PCB/project bytes are unchanged.

This is a separate design revision, not a finished full-system board. Do not merge copper or use a different revision’s BOM, voltages, or bring-up image. No Gerber/drill/assembly manufacturing package is supplied. No hardware operation is established.

See [the current review](https://howardwhsrun.github.io/FPGA_4K/presentation/fpga/) and [bring-up status](Current_Design_Bringup_Status.md). `Package_Manifest.json` records source hashes and the packaging-only transformation.
