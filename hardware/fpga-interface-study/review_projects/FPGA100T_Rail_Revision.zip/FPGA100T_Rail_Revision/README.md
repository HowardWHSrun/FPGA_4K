# FPGA100T Rail Revision — review only

Open `hardware/FPGA100T_Full_System.kicad_pro` in KiCad. Keep this complete extracted folder together. Custom symbol and footprint libraries are included; generic 3D model assets from the KiCad installation are not bundled.

128 components; 347 unconnected items in fresh native DRC. Changes boot/flash/oscillator/JTAG to 1.8 V and bank 16 to approximately 2.5 V, with C92/R122. Does not include the two mezzanines, cable protection or the later minimal-core ground routing. The XDC is a fragment, not a complete firmware build. The 20-page PDF corresponds to this schematic revision.

This is a separate design revision, not a finished full-system board. Do not merge copper or use a different revision’s BOM, voltages, or bring-up image. No Gerber/drill/assembly manufacturing package is supplied. No hardware operation is established.

See [the current review](https://howardwhsrun.github.io/FPGA_4K/presentation/fpga/) and [bring-up status](Current_Design_Bringup_Status.md). `Package_Manifest.json` records source hashes and the packaging-only transformation.
