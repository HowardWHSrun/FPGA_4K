# Editable learning report — 26 September 2026

Open `FPGA100T_Learning_And_Professor_Review.tex` in a LaTeX editor. It is a complete standalone document: the diagrams and tables are embedded, with no external images or input files. Compile with a standard LaTeX installation or Tectonic. The PDF has 33 pages, clickable contents and searchable component/pin identifiers.

The `data/` folder preserves the ledgers used to explain the circuit. Its `Source_Manifest.json` records source paths, hashes and the one portability change: the local workstation prefix in `Final_Frozen_Readback.json` is removed. That change does not change a circuit value, pin or check result.

## Read or present

- **Pages 3–8:** learn the system, power, capacitors, startup and pin-status language.
- **Pages 9–11:** locate FPGA balls and connector contacts visually.
- **Pages 12–13:** understand component-reduction choices and remaining engineering work.
- **Page 14:** short professor briefing with likely questions and answers.
- **Page 15:** sources and the exact native-board revision.
- **Pages 16–33:** look up every one of the 130 components and 762 distinct numbered electrical endpoints.

## Engineering limits

This report describes the smallest published 33 × 36 mm / 130-component routing checkpoint, native board SHA-256 `ae601df3925e5ec5e90c8a2e747356e432d0558e820199cf7c01c6bf8a7fef96`. It does not modify CAD. Two FPGA diode pins need a ground correction; four converter FB2 pins require grounding review. There are 146 missing assigned-net connections and 331 unassigned endpoints. The 117 ASIC signal proposal and cable data link are not yet assigned in the native design. The design is not ready for manufacturing.

The earlier 26-page component/pin report remains a historical record. Use this learning report for the corrected interpretation of its six saved NC markers. A report review is not an electrical or functional sign-off.
