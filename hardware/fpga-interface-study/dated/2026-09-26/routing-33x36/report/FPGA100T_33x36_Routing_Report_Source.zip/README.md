# Current FPGA report source - 26 September 2026

This is the 33 x 36 mm, 130-component partially routed board report. It is not a fabrication package.

Open FPGA100T_33x36_Routing_Component_Pin_Report.tex in the Codex built-in LaTeX editor, or compile it using an existing LaTeX/Tectonic installation. The source is self-contained: the native-data vector figure and all tables are embedded, with no image files or extra TeX input dependencies. For Tectonic, run:

tectonic FPGA100T_33x36_Routing_Component_Pin_Report.tex

The separate final PDF has 26 pages. Its component ledger includes all 130 references; its pin tables include all 762 distinct numbered endpoints; its net ledger includes all 48 functional nets. The CSVs and JSON evidence in data/ preserve the inputs and board identity. The original earlier placement-only report is unchanged.

C = whole assigned net connected by native DRC; P = assigned net still has opens; U = unassigned; NC = intentional no-connect. A P label does not assert that the particular pad is disconnected. Physical DRC is 0 and parity is 0, but 146 power/ground connections and 331 unassigned endpoints remain. The source report explicitly identifies U4.11, absent input protection, unresolved ASIC/link electrical contracts and unqualified power/thermal/assembly performance.
