# GTP power revision — 28 September 2026

The actual schematic now contains both missing GTP supply circuits. The existing core regulator remains separate, following AMD's recommendation that GTP regulators not share non-transceiver loads. This is an unrouted engineering proposal for review, not a qualified power design.

- [Integrated 13-sheet schematic PDF](output/FPGA50T_GTP_Power_Review.pdf)
- [Editable KiCad project](project/hardware/FPGA50T_8L_Unrouted.kicad_pro)
- [Complete portable project ZIP](FPGA50T_GTP_Power_Review_2026-09-28.zip)

Start with **sheet 13** for the connected regulators and filters, then **sheet 12** for FPGA power balls, the calibration resistor and manual configuration hold. Sheets 1, 6, 7 and 9 explain the updated overall power path. The earlier 12-sheet revision is preserved in the September 27 folder.

## What changed

| Circuit | New role | Connections |
| --- | --- | --- |
| U2 | Existing core/BRAM supply | Unchanged; no connection to either GTP output rail |
| U7 + L5 | New dedicated GTP 1.0 V regulator | 3.10 kΩ / 6.98 kΩ feedback; nominal 1.010888 V before FB1 |
| U4 + L3 | Former 2.5 V regulator repurposed for GTP 1.2 V | R5/R6 changed to 5.05 kΩ / 6.98 kΩ; nominal 1.206447 V before FB2 |
| FB1 / FB2 | Separate filter beads | TDK MPZ2012S300AT000; maximum specified DCR 10 mΩ; PCB geometry uses the manufacturer's recommended land dimensions |
| C128-C130 / C131-C133 | Local GTP bypass | Each rail has one 4.7 µF and two 100 nF capacitors after its bead |
| TP124 / TP125 | Filtered rail measurements | MGTAVCC / MGTAVTT; final PCB placement must be close to the FPGA supply connections |
| TP126 / TP127 | Regulator power-good measurements | Both new PG pull-ups use 1.8 V |
| J6 | Manual configuration hold | Shunt shorts FPGA_INIT_B to ground; existing R109 4.7 kΩ pull-up is retained |

The unused VCC_LINK_2V5 rail and C57-C63 are removed. R123 remains 100 Ω, 1%, between MGTRREF and MGTAVTT. The four GTP channels still need an external interface and reference-clock design.

## Startup and first-prototype procedure

The drawn chain is core U2 → auxiliary U3 → GTP U7 → GTP U4. I/O regulator U5 starts after auxiliary power-good, in parallel with U7. U7 power-good enables U4; it is pulled to 1.8 V. The existing core/auxiliary PG nodes still use their inherited 12 V pull-ups.

**J6 is a manual first-prototype control, not permission to power the present draft.** After the outstanding electrical and layout work is completed: fit the J6 shunt before applying power, measure all FPGA rails at the load, remove the shunt only after every rail is within its permitted range and stable, then configure through JTAG. INIT_B is used because holding PROGRAM_B low from initial power-on does not provide the same startup hold. J6 does not supervise brownouts or guarantee shutdown sequencing.

Raw regulator PG thresholds are too loose to establish the GTP voltage limits. An automatic all-rail supervisor and verified shutdown behavior remain future engineering work.

## What the calculations establish

AMD specifies MGTAVCC 0.97-1.03 V and MGTAVTT 1.17-1.23 V. Its GTP noise target is below 10 mV peak-to-peak at the FPGA supply inputs over 10 kHz-80 MHz. The small regulator setpoint offsets provide allowance for bead resistance; voltage must be checked at the FPGA.

The [DC budget](research/GTP_Filter_DC_Budget.json) includes resistor tolerance, regulator accuracy, feedback leakage, bead drop and an assumed ±5 mV noise allocation. **1 A per rail is an illustrative design case, not a predicted load or approved capacity.** The temperature sensitivity case leaves narrow margins. Actual current must come from XPE/Vivado with the selected lane rates, activity, clocks, transmitter settings and temperature. Hot bead resistance, PCB drop, filter resonance, transient response and measured ripple are not closed by this calculation.

The feedback resistance requirements are selected; exact 0603 ordering codes remain procurement TBD. The research includes a verified 0402 alternative for 6.98 kΩ, which is **not** silently substituted into the 0603 footprints.

## Remaining gates

- Input source, custom micro-HDMI cable, current limit, inrush, polarity/surge protection and cable current rating remain unresolved. The inherited LINK_12V entry has not been redesigned in this GTP-only revision.
- Complete a full FPGA rail-current and thermal budget, then verify converter stability and the ferrite/capacitor network with vendor models and measurements.
- Place GTP decouplers at the documented package pins, maintain short return loops and meet the final eight-layer stack/impedance requirements. Geometric PCB fit is not power-layout qualification.
- Verify startup, all-rail configuration hold, brownout behavior and power-down order. Complete GTP reference clock and receiver/cable decisions.
- Resolve the remaining native ERC findings; no checks were suppressed to claim electrical approval.

## Sources and validation

The final native checks confirm **141 schematic components / 145 PCB footprints**, including four mounts; 232 nets; eight copper layers; and zero routed tracks, vias or copper pours. Native PCB DRC reports **0 physical violations, 0 schematic/PCB differences and 499 unrouted connections**. The independent schematic audit passes 27/27 connection checks. ERC still reports 49 findings (26 isolated labels, 14 pin-model conflicts, eight reserved J4 pins and one MGTRREF power-input-model finding); these remain recorded, not waived. These checks establish connection correspondence and geometric clearance, not working power quality.

- [AMD requirements and exact package balls](research/AMD_GTP_Power_Requirements.md)
- [Filter parts, manufacturer links and calculation assumptions](research/GTP_Filter_Parts_Evidence.md)
- [Native schematic netlist](validation/GTP.net) and [ERC report](validation/GTP_ERC.json)
- [Change manifest](validation/Design_Changes.json)
- [Independent schematic audit](validation/Independent_GTP_Audit.json)
- [Final PCB audit](validation/GTP_PCB_Final_Audit.json), [native PCB DRC](validation/GTP_Final_DRC.json) and [preservation check](validation/GTP_PCB_Preservation.json)

Extract the entire ZIP before opening the project. Keep `project/hardware` and `project/libraries` together. The board retains the 50T CSG325, eight copper layers and unrouted review status; none of the older routed or placement studies are replaced.
