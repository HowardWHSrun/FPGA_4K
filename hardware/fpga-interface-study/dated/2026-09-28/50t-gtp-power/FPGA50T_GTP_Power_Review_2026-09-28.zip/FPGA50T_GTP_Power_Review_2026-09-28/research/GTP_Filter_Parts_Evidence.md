# GTP supply filter and divider evidence — 28 September 2026

Review draft only. The 1 A per-rail study envelope is not an FPGA power estimate and is not a qualified current limit. The JSON next to this file contains the reproducible arithmetic and every assumption.

## Candidate filter

TDK MPZ2012S300AT000: 0805 / 2012 body, 30 ohm at 100 MHz (±10 ohm), maximum 10 milliohm DC resistance, 6 A catalogue current. Its recommended land pattern has two 0.8 × 1.2 mm pads separated by 1.0 mm; derived pad centres are ±0.9 mm. Check the chosen KiCad footprint against this drawing. Current derates above 85°C. Nominal 100 MHz impedance is not proof of attenuation at the switching frequency or at the intended bias.

- [TDK product specifications](https://product.tdk.com/en/search/emc/emc/beads/info?part_no=MPZ2012S300AT000)
- [TDK family datasheet, pages 1–3](https://product.tdk.com/info/en/catalog/datasheets/beads_commercial_power_mpz2012_en.pdf)

## Divider choices

Use 3.10 kohm / 6.98 kohm for 1.010888 V nominal, and 5.05 kohm / 6.98 kohm for 1.206447 V nominal. Specify 0.1% initial tolerance, 25 ppm/K maximum TCR or better. These slightly elevated source voltages reserve some bead/PCB drop allowance; the required voltage at the FPGA remains 1.0 V / 1.2 V nominal.

The 6.98 kohm part is verified as Panasonic ERA2AEB6981X, 0402, 0.1%, ±25 ppm/K, 63 mW. Exact 3.10 kohm and 5.05 kohm ordering parts remain procurement TBD; Vishay TNPW0402 e3 supports the relevant E192 / 0.1% family range, but no exact product listing or stock was verified.

- [Panasonic 6.98 kohm product](https://industrial.panasonic.com/ww/products/pt/high-precision-chip-resistors/models/ERA2AEB6981X)
- [Vishay TNPW e3 family](https://www.vishay.com/docs/28758/tnpw_e3.pdf)

TI gives 0.7 V feedback, ±1% feedback accuracy in PWM, and 70 nA maximum feedback leakage. Low resistor values reduce leakage sensitivity. Keep forced PWM enabled; place VOS at the converter output capacitor. Feedback is before the proposed filter, so load-side voltage must include series voltage drop.

- [TI TPS62135 datasheet, §§7.5, 10.1.1, 10.1.2, 10.3.2](https://www.ti.com/lit/ds/symlink/tps62135.pdf)

## Limited DC screen

At 1 A, with maximum 10 milliohm bead resistance, 0.1% dividers, ±1% reference, worst-sign 70 nA feedback leakage, and an assumed 10 mV peak-to-peak ripple allocation:

| Domain | Pin range before additional PCB drop | Remaining low-side PCB / hot-bead budget | High-side remaining margin |
| --- | --- | --- | --- |
| MGTAVCC | 0.984947–1.026843 V | 14.947 mV | 3.157 mV |
| MGTAVTT | 1.178027–1.224889 V | 8.027 mV | 5.111 mV |

These fit AMD's 0.97–1.03 V / 1.17–1.23 V recommended ranges under the listed assumptions. A 100 K resistor-temperature excursion with independent ±25 ppm/K drift reduces the low-side budgets to 13.415 / 5.530 mV, and high-side margins to 1.579 / 2.541 mV. A 3 milliohm extra PCB path consumes another 3 mV at 1 A. Hot ferrite resistance, aging and dynamic overshoot/undershoot are not bounded here: this is **not** a power-integrity pass.

- [AMD DS181, Table 2](https://docs.amd.com/v/u/en-US/ds181_Artix_7_Data_Sheet); supply limits also checked in the project's saved PDF.

## Checks still required

The proposed 22 uF pre-filter and 4.7 uF + 2 × 100 nF post-filter values need effective-capacitance and frequency-domain review. Simulate/check DC-bias reduction of ferrite impedance, filter peaking, regulator stability, and package/plane resonances. Measure startup, shutdown, ripple spectrum, FPGA-pin voltage and load transients. Establish rail demand in XPE and verify thermals and the complete power-return path. Neither the bead nor the arithmetic establishes the required GTP noise performance.
