# GTP power requirements — 2026-09-28

Read-only source review for the XC7A50T-CSG325 draft. This records requirements and design-review findings, not measured hardware performance.

## AMD GTP guidance

Primary source: [UG482 v1.9](https://docs.amd.com/api/khub/documents/Xk_zMbXsJj92suJ4_0Akkg/content), verified against the saved manufacturer PDF in the September 27 50T review.

| Location | Requirement / implication |
|---|---|
| p236, Table 5-14 | Dedicated final regulators for MGTAVCC and MGTAVTT; AMD advises against sharing their regulators with non-transceiver loads. A direct connection or ferrite from the FPGA core supply does not follow this recommendation. |
| pp228, 234 | Target less than 10 mV peak-to-peak supply noise at the FPGA; p234 specifies 10 kHz–80 MHz. Switching regulators need suitable filtering. |
| p230, Table 5-7 | Per supply group, each analog rail needs one 4.7 µF and two 100 nF ceramic capacitors, ±10%. Larger capacitors go near the package perimeter; 100 nF capacitors near supply balls. |
| p220, Table 5-2 | XC7A50T-CSG325 has one GTP power group. |
| p219 | All analog supplies must be within tolerance before configuration, when termination calibration occurs. MGTRREF connects through 100 Ω precision resistance to MGTAVTT. |

**Result:** use a dedicated 1.0 V GTP regulator and a separate 1.2 V regulator. Their PCB placement, filter response, noise, current and heating remain to be checked.

## Supply limits and sequencing

Primary source: [DS181 v1.27.1](https://docs.amd.com/v/u/en-US/ds181_Artix_7_Data_Sheet), July 3, 2024; local PDF independently read.

- p2: MGTAVCC 0.97–1.03 V; MGTAVTT 1.17–1.23 V.
- p8: core and MGTAVCC can rise in either order or together; MGTAVTT follows both. Recommended shutdown reverses that order.
- p9, Table 7: each supply's 0–90% rise time is 0.2–50 ms.
- p8: early MGTAVTT can cause substantial extra startup current. A startup PG chain does not demonstrate acceptable shutdown behavior.
- Use XPE with actual lane count, rate, PLL settings, transmitter settings and temperature for current estimates.

Calculation on the prior core circuit: 1.024928 V × 1.01 = 1.035177 V. Thus merely sharing its pre-resistor node also gives insufficient allowance against the GTP 1.03 V maximum. This calculation is illustrative, not a complete core-regulator tolerance analysis.

## Exact package balls and capacitor targets

Source: AMD `xc7a50tcsg325pkg.csv` in the September 27 `16_50T_Eight_Layer_Review/source_evidence/` folder, checked against UG482 p233 Table 5-10.

| Rail | Every FPGA supply ball | Recommended 100 nF supply/ground ball pairs |
|---|---|---|
| MGTAVCC | B4, C5, E5, F5 | B4–B3; F5–F6 |
| MGTAVTT | A2, C1, E1, F3, G2 | F3–F4; A2–A1 |
| MGTRREF | A6 | 100 Ω ±1% to MGTAVTT; retain R123 |

## Configuration hold — selected manual first-prototype control

Primary source: [UG470 v1.17](https://docs.amd.com/api/khub/documents/FOs3lXmlcWxBhTIFxVKyGA/content), December 5, 2023, pp21, 78, 81.

- **Do not use PROGRAM_B held low as the startup hold.** AMD explicitly states that holding it low from power-on does not keep configuration reset.
- Hold **INIT_B** low before mode sampling to delay configuration. Preserve PROGRAM_B as a separate reset function.
- INIT_B and PROGRAM_B each require an external pull-up of at most 4.7 kΩ to VCCO_0.
- The selected draft uses J6 to short INIT_B to ground. Install its shunt before power-up, measure all required rails in tolerance and stable, then remove the shunt and start JTAG programming. Do not start JTAG configuration before that measurement.
- Pulling INIT_B low after startup is not a brownout reset. A full restart/supervision strategy remains a separate requirement.
- JTAG remains subject to operator/programmer control; do not claim INIT_B alone qualifies all JTAG operations.

## TPS62135 PG limitations

Primary source: [TI TPS62135 datasheet, revision B](https://www.ti.com/lit/ds/symlink/tps62135.pdf), pp5 and 9.

PG is an open-drain indication suitable for sequencing. It can sink 2 mA; a 1.8 V / 4.7 kΩ pull-up requires about 0.38 mA. PG remains low for disable/UVLO/thermal shutdown only while VIN is present.

Its rising threshold spans **93–98%** of output, with 96% typical. Therefore PG can release before a GTP rail reaches its minimum permitted operating voltage. PG alone also does not sense a post-filter voltage drop. Use an appropriate accurate supervisor / settling mechanism, or retain a documented manual wait-and-measure requirement for the review draft. Do not label the raw PG node as proof that both GTP rails are in tolerance.

## Review disposition

The proposed dedicated U7 1.0 V buck and repurposed U4 1.2 V buck are a defensible draft architecture if both have local filtering and decoupling and no DC tie to the core rail. Core PG → auxiliary → GTP 1.0 V → GTP 1.2 V gives the intended startup order. J6 provides manual INIT_B hold; PROGRAM_B retains its separate reset function. U7 PG only enables U4 and is exposed for measurement; U4 PG is also exposed, both using 1.8 V pull-ups. Neither PG is labeled as accurate final-rail qualification. An automatic all-rail supervisor and reverse shutdown control remain open. Exact voltage qualification, filter damping/impedance, startup and shutdown waveforms, current estimates, regulator stability and thermal performance remain unverified.
