# Carrier_V1 public review - 26 October 2026

Open Carrier_V1.kicad_pro in KiCad 10. This model-free public package contains the current editable PCB, one-page schematic, project settings/rules and all registered project-local 2D libraries. The PCB and footprint libraries preserve their exact non-model native geometry, fields, nets, placements, routing, zones and cached fills. Model-reference and embedded-file blocks are removed for public distribution; all other native content is preserved. The source PCB hash is recorded in source-manifest.json.

The verified local native assembly contains all 80 fitted component-body models, plus 8 bare test pads and 4 mounting holes. Native DRC reports 0 findings, 0 unconnected items and 0 schematic/PCB mismatches under the retained rules and exclusions. These are CAD checks, not powered electrical/thermal/EMI, mechanical-tolerance or fabrication qualification. See verification.json for the exact scope and retained ignored categories.

No supplier STEP/STP/WRL files, native 3D meshes, embedded supplier payloads, private reports, histories, preferences, caches or chat material are included. The public viewer uses independently authored nominal geometry and rendered review images. The complete local native assembly and supplier-model archive remain separate; this model-free ZIP will not show component bodies by itself in KiCad3D.
