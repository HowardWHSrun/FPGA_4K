# Source and library notices

This carrier uses project-local 2D symbols and footprints inherited or adapted from the BRK8305 reference and cited manufacturer drawings. Native schematic source boxes identify engineering references and changes; footprint descriptions retain their source links. Standard KiCad-derived library material retains the KiCad library license and electronic-design exception in KICAD_LIBRARY_NOTICE.md. This notice does not relicense manufacturer material. No supplier 3D geometry or model payload is included in this public package.
