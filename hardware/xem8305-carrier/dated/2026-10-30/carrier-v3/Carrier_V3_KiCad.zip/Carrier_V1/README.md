# LDO carrier V3 — KiCad download

Open `Carrier_V1.kicad_pro` in KiCad 10.0.6 or newer. Keep the project files and `libraries` directory together. The project-local tables resolve 35 board footprint masters and one additional inherited footprint reference on two GND power symbols; four small standard symbol libraries contain only the definitions used by this schematic. The three used custom symbol libraries are included unchanged.

This public copy omits all 3D model references, embedded 3D payloads and model files. The schematic, project settings and design rules retain their frozen V3 bytes; the PCB differs only by removal of those 3D blocks. Copper, filled zones, pads, footprint identifiers/placement, nets and schematic fields are preserved. The original frozen V3 PCB SHA-256 is `fe45d77ec0ef33c40660fcb0f68ed85daa38d3468264f7bbc36fc5da2bce8cd2`.

KiCad-derived library material is provided under CC-BY-SA 4.0 with the KiCad design exception; retain `KiCad_Library_License.md` and any existing file attribution. This notice does not claim a new license over supplier-origin design material.

Use the matching V3 JLCPCB files for engineering review and quotation. J1/J2's Hirose lands still need JLC's explicit CAM decision before production. Native CAD checks do not establish fabrication/assembly acceptance or powered hardware qualification.
