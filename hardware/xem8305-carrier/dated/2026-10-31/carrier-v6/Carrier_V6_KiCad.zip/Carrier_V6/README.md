# Direct LDO Carrier V6 — KiCad project

Open `Carrier_V6.kicad_pro` in KiCad 10.0.6 or newer. Keep the complete `Carrier_V6` folder, local library tables and `libraries` directory together. Main filenames, schematic project-instance names and visible board/schematic revision are V6. Historical custom symbol/footprint identifiers and circuit-note revision provenance are retained to preserve dependencies and attribution.

V6 adds the direct MC2.14 VREFP-to-MC2.16 GNDADC copper connection for the XEM8305 internal SYSMON reference. It retains the original 80 fitted parts and placements and the original input circuit. The withdrawn input-protection redesign is excluded.

The public PCB omits all model references and embedded 3D payloads. Its complete non-3D electrical/layout token stream matches the saved V6 source. The schematic differs only by changing its project-instance name from Carrier_V1 to Carrier_V6. Project settings/rules and used library definitions are preserved; the local tables include all required custom and used standard symbol/footprint definitions. Supplier 3D bodies, private audit material and editor caches are omitted.

KiCad-derived library material is supplied under CC-BY-SA 4.0 with the KiCad design exception; retain `KiCad_Library_License.md` and existing attribution. This notice claims no new license over supplier-origin design material.

Use the matching V6 Gerbers, V6 assembly BOM and V6 native CPL. The native CPL is pending JLC library-model placement review; no machine-library offset/rotation correction is included. Factory CAM, populated fit, power sequencing, input robustness, USB ESD/provisioning and powered/thermal qualification remain open. Native checks do not establish manufacturing or hardware approval.
