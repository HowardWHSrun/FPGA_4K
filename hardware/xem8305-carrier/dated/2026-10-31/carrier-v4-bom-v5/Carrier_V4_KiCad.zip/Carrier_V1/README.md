# Direct LDO Carrier V4 — KiCad download

Open `Carrier_V1.kicad_pro` in KiCad 10.0.6 or newer. Keep all project files, local library tables and the `libraries` directory together. The native internal filename is preserved; the visible engineering revision is V4. The corrected assembly BOM grouping is V5 and introduces no CAD change. This Direct LDO Carrier is distinct from the standalone-FPGA companion LDO board and from the XEM8310 carrier.

This public copy omits all 3D model references, embedded 3D payloads and model files. Schematic, project settings and design rules retain their original V4 bytes. PCB and used footprint masters differ only by removal of model/embedded-file blocks; all other electrical/layout tokens are preserved. The source V4 PCB SHA-256 is `028ba09ae74aa1482c3d070c68390da1e267c3ecf704ac634aa2a8104a065315`.

All used custom symbol libraries, footprint masters and only the used standard-symbol definitions from the schematic cache are included through project-local tables. KiCad-derived library material is provided under CC-BY-SA 4.0 with the KiCad design exception; retain `KiCad_Library_License.md` and existing attribution. This notice does not claim a new license over supplier-origin design material.

Use the matching V4 Gerber/CPL and grouped V5 BOM for engineering review and quotation. Current JLC library placement/polarity verification remains pending, including J3/J4/U1/U3/U8. Native coordinates have not been changed to guess machine-library offsets or rotations. J1/J2's 0.20 mm Hirose lands need explicit factory CAM acceptance. File checks do not establish fabrication/assembly acceptance or powered hardware qualification.
